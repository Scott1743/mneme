---
type: Reference
title: 阿里巴巴官宣 Qwen3.8 大模型（2.4 万亿参数，即将开源）
description: 阿里巴巴官宣最新大模型 Qwen3.8（参数 2.4 万亿，称性能仅次于 Fable 5），预览版 Qwen3.8-Max 已上线 Token 计划/Qoder/QoderWork，正式版即将发布并开源。
resource: https://dy.163.com/article/L292EPT70534A4SC.html
tags: [ai-news, llm, alibaba, qwen, open-source, waic-2026]
timestamp: 2026-07-20T18:25:00+08:00
published_at: 2026-07-20T08:16:02+08:00
published_at_raw: "2026-07-20 08:16:02"
published_precision: datetime
retrieved_at: 2026-07-20T18:25:00+08:00
event_date: 2026-07-19
---

# What happened

2026-07-19 消息，界面新闻获悉阿里巴巴最新大模型「Qwen3.8」即将正式发布，参数量达 2.4 万亿，官方称其为当今最强模型之一、性能仅次于 Fable 5，且兼容主流前沿 AI 架构。目前 Qwen3.8-Max 预览版已率先登陆阿里巴巴 Token 计划、Qoder 及 QoderWork 平台，用户可抢先体验；正式版计划发布并开源。

# Why it matters

阿里将 Qwen 系列推至 2.4T 参数规模并预告开源，延续国产大模型「开源+超大参数」路线，与 Kimi K3（2.8T 开源）、DeepSeek V4 形成国产超大模型密集迭代态势，进一步压缩与前沿闭源模型的差距，并借开源生态抢占开发者心智。

# Evidence and caveats

- 来源为界面新闻 WAIC 报道（2026-07-20 08:16），消息日期 2026-07-19，信息一致。
- 为「即将发布」的官宣，目前仅预览版上线，正式版与开源时间待定；2.4T 参数与「仅次于 Fable 5」为厂商口径，具体基准表现待正式发布与独立评测。
- Fable 5 为外部闭源模型代号，指代以厂商表述为准；属厂商发布。

# Citations

1. [界面新闻/网易 · AI早报：阿里 Qwen3.8 即将发布，2.4 万亿参数](https://dy.163.com/article/L292EPT70534A4SC.html)
