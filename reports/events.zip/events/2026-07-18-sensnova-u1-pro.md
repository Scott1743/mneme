---
type: Reference
title: 商汤发布旗舰级 SenseNova U1 Pro「交付级」原生多模态智能体基座
description: 商汤 2026-07-18 在 WAIC 发布 SenseNova U1 Pro，定位面向长程任务的「交付级」原生多模态智能体基座，基于 NEO-unify 内核统一语言与视觉表征，支持原生 8K 输出与长程 Agentic 闭环。
resource: https://www.163.com/dy/article/L2576SI705118O92.html
tags: [ai-news, model-release, multimodal, agent, sensnova, waic-2026]
timestamp: 2026-07-19T11:25:00+08:00
published_at: 2026-07-18T20:22:07+08:00
published_at_raw: "2026-07-18 20:22:07 来源：钛媒体APP"
published_precision: datetime
retrieved_at: 2026-07-19T11:25:00+08:00
event_date: 2026-07-18
---

# What happened

- 2026-07-18 在 2026 世界人工智能大会（WAIC）上，商汤科技发布「日日新 SenseNova U」系列的旗舰新品 SenseNova U1 Pro（U1 Pro）。
- U1 Pro 定位为面向长程任务（long-horizon）的「交付级」原生多模态智能体基座，实现理解、生成与行动的深度统一；商汤称行业正从「单点式内容生成」迈向「系统级内容交付（Delivery）」。
- 底层核心为 NEO-unify 内核架构，在原生多模态体系中实现语言与视觉的统一表征，打破理解与生成的割裂壁垒。
- 四大核心交付能力：巅峰设计美感（告别「AI 味」）、原生 8K 超清输出、极致的图文与细节控制、长程 Agentic 闭环思维（支持数十轮 Agentic Generation Loop，并实现整体风格与局部文本同步可控编辑）。
- 预览版已开启邀请测试，正式版预计 2026 年 8 月上线对公众开放服务，并同步推出定价与 API。

# Why it matters

- 多模态 AI 从「能生成」走向「能稳定交付」的标志性产品：以「交付级」标准替代反复「抽卡」，把图像/视频创作拉入可闭环、可验证的生产工作流，与代码领域从 Copilot→Vibe Coding→Agentic Coding 系统级交付的演进路径对应。
- 商汤基础模型 SenseNova U1 今年 4 月开源，两月内 GitHub 总 Star 数突破 8000、6 月用户人均日生图量较 5 月提升近 3 倍，显示开源多模态模型已深度切入真实工作流；U1 Pro 是其旗舰化与商业化闭环的进一步延伸。

# Evidence and caveats

- 能力描述、架构（NEO-unify）、8K 输出与 Agentic 闭环等来自商汤官方发布经钛媒体/界面新闻刊发的报道，属厂商侧发布（vendor-sourced）；「媲美全球顶尖模型」「交付级」等为厂商表述，具体质量以实际产出与第三方评测核验。
- 预览版邀测阶段，正式版与 API 定价 8 月才公布；基准与对比数据未在公开稿中给出可复现评测细节。

# Citations

1. [商汤发布旗舰级 SenseNova U1 Pro，多模态智能体实现长程任务闭环（钛媒体 APP）](https://www.163.com/dy/article/L2576SI705118O92.html)
2. [商汤科技发布 SenseNova U1 Pro 大模型（界面新闻经网易）](https://www.163.com/dy/article/L253KQP90534A4SC.html)
3. [SenseNova U1 Pro 官网（商汤）](https://www.sensenova.cn/u1-pro)
