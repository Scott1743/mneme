---
type: Reference
title: ChatGPT begins citing Kalshi prediction-market data
description: The New York Times (2026-07-13) reported that OpenAI and Kalshi have a deal to surface Kalshi prediction-market data in ChatGPT for queries such as World Cup forecasts; example prompt "France and Spain" returned a win forecast attributed to Kalshi.
resource: https://www.nytimes.com/2026/07/13/technology/kalshi-openai-chatgpt-world-cup-odds.html
tags: [ai-news, openai, kalshi, prediction-market, distribution]
timestamp: 2026-07-15T10:59:00+08:00
published_at: 2026-07-14
published_at_raw: "2026-07-13 (NYT), 2026-07-14 (Verge coverage)"
published_precision: date
retrieved_at: 2026-07-15T03:00:00Z
event_date: 2026-07-14
---

# What happened

The New York Times reported on 2026-07-13 that OpenAI has struck a deal with
Kalshi, the federally regulated US prediction market, to surface Kalshi
prices and forecasts in ChatGPT answers. The Verge covered the integration
on 2026-07-14 with a sample prompt — "France and Spain" — that returned a
win forecast attributed to Kalshi alongside the World Cup matchup.

Prediction markets are increasingly being routed into general-purpose chat
front-ends. Kalshi and Polymarket have already inked deals with AP, with
newsletter writers, and with X creators, per The Verge. Routing Kalshi data
into ChatGPT adds a major consumer chatbot as a new distribution surface.

# Why it matters

Prediction markets are a structured, real-time signal class that fits the
"answer with a number" idiom chat assistants are optimized for. For end
users, the integration converts ChatGPT from "explain what Kalshi says"
into "show Kalshi's number." For Kalshi, ChatGPT becomes a discovery funnel
for event-contract interest. Expect competitors (Polymarket, betting
exchanges) to push for similar surfacing, and expect the labelling question
— what gets cited, what's an ad, what's an opinion — to intensify.

# Evidence and caveats

Primary: NYT report (subscription-walled); The Verge's reproduction of a
"France and Spain" prompt and resulting ChatGPT output. Treat Kalshi as the
benefited counterparty and OpenAI / Kalshi as commercial sources. As of
this writing, no OpenAI post lists Kalshi as a Citations integration.
Quality score 9, promotional risk 0.

# Citations

1. [NYT — Kalshi × OpenAI (2026-07-13)](https://www.nytimes.com/2026/07/13/technology/kalshi-openai-chatgpt-world-cup-odds.html)
2. [The Verge — ChatGPT is now citing Kalshi data](https://www.theverge.com/news/761665/chatgpt-kalshi-prediction-market-world-cup)
