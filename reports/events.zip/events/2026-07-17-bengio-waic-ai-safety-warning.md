---
type: Reference
title: 图灵奖得主本吉奥在 WAIC 警告：AI 安全措施已追不上能力狂飙
description: 图灵奖得主 Yoshua Bengio 于 2026-07-17 在 WAIC 科学前沿论坛远程警告"AI 既降低作恶门槛，又抬高危害上限"，指当前安全措施已追不上 AI 能力；周伯文披露 AI 编程成功率 18 个月从 5% 升至 88%、科学发现完成率仍停滞约 3%。
resource: https://view.inews.qq.com/a/20260717A0C9J800
tags: [ai-news, ai-safety, commentary, bengio, waic, governance]
timestamp: 2026-07-18T11:25:00+08:00
published_at: 2026-07-17
published_at_raw: "2026-07-17 WAIC 科学前沿论坛"
published_precision: date
retrieved_at: 2026-07-18T11:25:00+08:00
event_date: 2026-07-17
---

# What happened

- 图灵奖得主 Yoshua Bengio（本吉奥）在 2026 世界人工智能大会（WAIC）科学前沿论坛远程警告："AI 既降低作恶门槛，又抬高危害上限"，指出当前安全措施已追不上 AI 能力的狂飙。
- 同场，周伯文披露数据：过去 18 个月 AI 编程成功率从 5% 升至 88%，但科学发现完成率仍停滞在约 3%，呼吁以"内生安全"重构 AI 防护体系。

# Why it matters

- 在 WAIC 2026（以"智能伙伴"为主题、密集展示 Agent 与具身智能落地）的背景下，顶尖学者对安全与能力错位的警示，为行业的"能力冲刺"提供了关键反平衡视角。
- "内生安全"而非"外挂护栏"的提法，提示安全设计需前置到模型与系统架构本身。

# Evidence and caveats

- 为论坛发言/观点性内容（commentary），由腾讯科技等媒体报道；属"confirmed"已发生之发言，但其判断与建议不构成可独立验证的技术结论。
- 18 个月 5%→88% 的编程成功率数据来自周伯文现场披露，具体测量口径与基准待后续公开材料核验。

# Citations

1. [腾讯科技（经腾讯新闻转载）：图灵奖得主本吉奥警告 AI 安全措施追不上能力](https://view.inews.qq.com/a/20260717A0C9J800)
