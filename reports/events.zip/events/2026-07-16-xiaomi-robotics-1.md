---
type: Reference
title: 小米发布具身基座模型 Xiaomi-Robotics-1，初步验证机器人 Scaling Law
description: 小米 2026-07-16 发布具身智能基座模型 Xiaomi-Robotics-1，基于 10 万小时真实操作数据预训练，在 RoboDojo、RoboCasa365 等基准登顶，代码与权重将陆续开源。
resource: https://robotics.xiaomi.com/xiaomi-robotics-1.html
tags: [ai-news, embodied-ai, robotics, open-source, xiaomi]
timestamp: 2026-07-17T11:25:00+08:00
published_at: 2026-07-16
published_at_raw: "2026-07-16（IT之家/凤凰网科技报道；雷军微博官宣）"
published_precision: date
retrieved_at: 2026-07-17T11:25:00+08:00
event_date: 2026-07-16
---

# What happened

- 小米于 2026-07-16 正式发布具身智能基座模型 Xiaomi-Robotics-1（VLA/机器人策略基础模型）。
- 预训练阶段使用 10 万小时真实世界操作轨迹（UMI 设备采集，覆盖家庭/商业/工业/办公室/户外等场景），通过 VLM 自动标注管线约 2 周完成全量标注。
- 后训练阶段使用约 1 万小时跨本体数据（7200+ 小时移动操作/双臂机器人数据、1000+ 小时人工标注 UMI、BridgeV2/RT-1/DROID 等公开集），完成本体对齐与指令对齐。
- 基准表现：RoboCasa365 平均成功率 57.4%（此前最优 46.6%）、RoboDojo 13.93% 成功率/20.07 分登顶、VLABench 59.1%、RoboCasa 74.5%；实验显示预训练数据 2.5K→20K 小时、模型 2B→10B 时动作预测损失持续下降、真实任务成功率提升。
- 新任务适配平均不足 10 小时数据微调即大幅超越 Pi-0.5；小米称代码与权重将陆续发布。

# Why it matters

- 被称为国内首次系统性验证具身智能 Scaling Law（数据/参数规模与策略性能同向提升）。
- 与 7-14 人形机器人、7-15 开源 U0（38B）构成小米"本体—数据—模型"闭环；降低新任务数据/训练成本，推动机器人走向真实世界。

# Evidence and caveats

- 官方项目主页 + IT之家/凤凰网科技独立报道 + 雷军微博；基准数字来自小米官方，未独立复现。
- 权重/代码"陆续发布"，截至报道时未完全公开；下游真实部署效果待验证。

# Citations

1. [Xiaomi-Robotics-1 官方项目主页](https://robotics.xiaomi.com/xiaomi-robotics-1.html)
2. [IT之家：小米推出具身基座模型 Xiaomi-Robotics-1，基于 10 万小时数据训练](https://new.qq.com/rain/a/20260716A05BNX00)
3. [凤凰网科技：小米发布机器人基座模型 Xiaomi-Robotics-1](https://new.qq.com/rain/a/20260716A05WQ200)
