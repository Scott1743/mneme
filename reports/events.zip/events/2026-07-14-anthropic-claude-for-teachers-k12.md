---
type: Reference
title: Anthropic launches Claude for Teachers for US K-12 educators
description: Anthropic released a free, verified-educator K-12 edition of Claude with Claude Code, Cowork, and integrations to ASSISTments, MagicSchool, Canva Education, Brisk Teaching, Coteach, Diffit, Eedi, Snorkl, TeachFX; tied to Learning Commons standards in all 50 states and piloted with Detroit Public Schools.
resource: https://www.anthropic.com/news/claude-for-teachers
tags: [ai-news, anthropic, education, k12, claude-for-teachers]
timestamp: 2026-07-15T10:59:00+08:00
published_at: 2026-07-14
published_at_raw: "Introducing Claude for Teachers"
published_precision: date
retrieved_at: 2026-07-15T03:02:28Z
event_date: 2026-07-14
---

# What happened

Anthropic announced [Claude for Teachers](https://www.anthropic.com/news/claude-for-teachers)
on 2026-07-14. Verified US K-12 educators get free access to premium Claude,
including Claude Code and the Cowork agent feature. Sign-ups are open through
2026-06-30, with a school- and district-wide tier to follow. Anthropic says it
won't train models on data shared through the product; student data is covered
by a FERPA-aligned K-12 Data Processing Addendum.

The product ships with a connector to [Learning Commons](https://learningcommons.org),
which grounds lesson planning in academic standards across all 50 US states plus
OpenSciEd and Illustrative Mathematics IM v.360 curricular resources.
It also integrates an ecosystem of nine K-12 tools (ASSISTments, Brisk
Teaching, Canva Education, Coteach, Diffit, Eedi, MagicSchool, Snorkl,
TeachFX). Anthropic is publishing the underlying teaching skills as an
[open-source repository](https://github.com/anthropics/k12-teacher-skills)
and an AI Fluency for K-12 Teachers course on Skilljar (co-created with Teach
for America, train-the-trainer module with the American Federation of
Teachers). A pilot evaluation runs in Detroit Public Schools.

# Why it matters

K-12 has become a competitive surface between Anthropic and OpenAI's
education-specific tooling. Bundling Claude Code + Cowork into a free,
verified-educator product raises the floor for what free AI assistance in a
classroom actually contains — agents that schedule recurring work, not just a
chat window. It also brings independent partner infrastructure (AFT, Detroit
Public Schools, Gates Foundation partnership, Playlab) into the offering,
which is unusual for a vendor release. The June 30, 2027 sign-up deadline is
the operational anchor.

# Evidence and caveats

Primary source: Anthropic blog post with linked educator quote from AFT
president Randi Weingarten and sign-up CTA. Vendor-sourced; treat Anthropic's
deployment claims as vendor claims until independent classroom results
publish. The Decoder and The Verge both covered the rollout on 2026-07-14 and
corroborate the integration list and K-12 target audience. Quality score 10,
promotional risk 1 (vendor, but fact-rich and originally announced).

# Citations

1. [Introducing Claude for Teachers — Anthropic](https://www.anthropic.com/news/claude-for-teachers)
2. [Claude for Teachers product page](https://claude.com/solutions/teachers)
3. [The Decoder — Anthropic is rolling out Claude for Teachers](https://the-decoder.com/anthropic-is-rolling-out-claude-for-teachers-a-free-offering-for-verified-k-12-educators-at-us-schools/)
4. [The Verge — Anthropic introduced a Claude product for K-12 teachers](https://www.theverge.com/ai-artificial-intelligence/964091/anthropic-claude-for-teachers-k12)
5. [Open-source teacher skills repo](https://github.com/anthropics/k12-teacher-skills)
