---
type: Reference
title: ChatGPT returns to WhatsApp in the EEA after EU interim measures
description: OpenAI re-enabled ChatGPT on WhatsApp in the 27 EU member states plus Liechtenstein, Iceland, and Norway via 1-800-CHATGPT; reachable since 2026-07-13 after the European Commission's June 2026 interim measures forced Meta to host rival AI bots. Also launching on Kakao (South Korea) and Viber.
resource: https://the-decoder.com/chatgpt-returns-to-whatsapp-in-europe-after-eu-forces-meta-to-open-the-door-to-rival-ai-bots/
tags: [ai-news, openai, meta, whatsapp, eu-regulation, distribution]
timestamp: 2026-07-15T10:59:00+08:00
published_at: 2026-07-14
published_at_raw: "2026-07-13 (effective)"
published_precision: date
retrieved_at: 2026-07-15T03:01:34Z
event_date: 2026-07-13
---

# What happened

OpenAI has re-enabled ChatGPT on WhatsApp in the European Economic Area (27 EU
member states plus Liechtenstein, Iceland, and Norway). The chatbot has been
reachable since 2026-07-13 via the verified contact 1-800-CHATGPT
(+1-800-242-8478), with no account required. Text prompts, image uploads,
voice messages, and image generation all work in many languages. Users can
link their WhatsApp account to their ChatGPT account so context carries over.
The bot identifies itself as running on GPT-5.5; image generation appears to
route to gpt-image-2.

The re-enable follows the European Commission's June 2026 [interim
measures](https://ec.europa.eu/commission/presscorner/detail/en/ip_26_1276)
that forced Meta to host competitor AI bots on WhatsApp again. Meta had
removed ChatGPT, Microsoft Copilot, and Perplexity from WhatsApp on
2026-01-15. OpenAI is also launching ChatGPT on Kakao (South Korea) and Viber
in other markets.

# Why it matters

This is the first major reversal of Meta's January 2026 policy that purged
third-party AI assistants from WhatsApp. The Commission's interim-measures
route bypasses the typical multi-year DMA proceedings and shows what
"interoperability pressure on Meta's AI surface" looks like in practice.
WhatsApp's reach inside the EEA (~450M+ potential users) makes this a
material distribution channel for OpenAI, and it establishes the regulatory
precedent that AI assistants on a dominant messaging app cannot be walled off
without ongoing legal risk.

# Evidence and caveats

Primary: European Commission press corner (interim measures decision). The
Decoder independently reported the re-enable on 2026-07-14 with a screenshot
of ChatGPT responding from the verified US number. OpenAI has not yet
published its own launch post for this re-enable. Boundary uncertainty
remains on usage limits without account linking and whether OpenAI routes
some requests to cheaper older models. Quality score 11, promotional risk 0.

# Citations

1. [European Commission interim measures, 2026-06](https://ec.europa.eu/commission/presscorner/detail/en/ip_26_1276)
2. [The Decoder — ChatGPT returns to WhatsApp in Europe](https://the-decoder.com/chatgpt-returns-to-whatsapp-in-europe-after-eu-forces-meta-to-open-the-door-to-rival-ai-bots/)
3. [The Decoder — Meta removes rival chatbots from WhatsApp (background)](https://the-decoder.com/meta-removes-rival-chatbots-from-whatsapp/)
