---
type: Reference
title: Tencent Hunyuan Hy3 tops OpenRouter global usage chart with 68x growth in first week
description: Tencent Hunyuan Hy3's total API call volume grew 68x vs predecessor Hy2 in its first week, topping the OpenRouter global model usage ranking. 60% of WorkBuddy self-selecting users chose Hy3. 1-bit and 4-bit quantized versions released for single-card deployment.
resource: https://hunyuan.tencent.com/
tags: [ai-news, market-data, tencent, hunyuan, openrouter]
timestamp: 2026-07-16T11:25:00+08:00
published_at: 2026-07-15T20:00:00+08:00
published_at_raw: "2026-07-15 · 新浪科技 / Chinaz"
published_precision: datetime
retrieved_at: 2026-07-16T11:25:00+08:00
event_date: 2026-07-15
---

# What happened

- One week after Hy3's official release (July 6, 2026), **total API call volume grew 68x** compared to predecessor Hy2.
- Hy3 **topped the OpenRouter global model usage ranking**, ending DeepSeek-V4-Flash's "seven-consecutive-win streak" on the platform.
- In WorkBuddy (an agent product), **60% of self-selecting users chose Hy3** as their model.
- Hy3 is a hybrid-reasoning MoE model: **295B total params, 21B active**, 256K context, fast/slow thinking mode switching. Performance comparable to flagship models 2-5x its size.
- On July 14, the team released **1-bit and 4-bit quantized versions** of Hy3, enabling single-card or local-machine deployment without multi-card clusters.
- Hy3 is integrated across WorkBuddy/CodeBuddy, 元宝, Marvis, ima, with APIs on Tencent Cloud TokenHub and overseas platforms.
- Chinese models' weekly call volume on OpenRouter reached 27.58T tokens (4x US models), with the top 6 all being Chinese models. US enterprises' usage of Chinese models has stabilized at 30-46% weekly since February 2026.

# Why it matters

- Signals a paradigm shift: the model competition is moving from pure parameter-scale rivalry to "extreme cost-effectiveness + on-device deployability", and Chinese open models are winning on that axis.
- The 68x growth and OpenRouter top ranking are independently verifiable market data (OpenRouter is a third-party platform), confirming that cost-effective open models are driving actual production adoption, not just buzz.
- The quantized versions lowering deployment门槛 further accelerates the "open-models-for-production" trend that Satya Nadella and Clem Delangue have been advocating.

# Evidence and caveats

- Primary source: Tencent Hunyuan official site + 新浪科技/Chinaz coverage. OpenRouter rankings are independently verifiable on the platform. 68x growth figure is from Tencent's own data; OpenRouter ranking confirms the magnitude. 每日经济新闻 independently calculated weekly Chinese model call volumes from OpenRouter data. The 60% WorkBuddy user figure is a vendor claim without independent verification.

# Citations

1. [Chinaz — 腾讯混元Hy3发布首周调用量增超68倍](https://www.chinaz.com/ainews/29632.shtml)
2. [新浪科技 — 腾讯混元Hy3上线一周总调用量增长超68倍](https://new.qq.com/rain/a/20260715A0AFNA00)
3. [每日经济新闻 — 中国大模型周调用量达27.58万亿Token](https://www.toutiao.com/article/7661844772369302043/)
