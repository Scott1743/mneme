---
type: Reference
title: 商汤开源 SenseNova-Vision 统一视觉理解生成大模型
description: 商汤发布并全面开源日日新 SenseNova-Vision，单一模型统一结构化视觉理解、稠密几何预测、图像分割与多视角 3D 几何四大任务，登顶 Hugging Face Any-to-Any Leaderboard 开源榜第一。
resource: https://arxiv.org/abs/2607.06560
tags: [ai-news, vision, open-source, sensnova, shanghai-ai]
timestamp: 2026-07-16T18:25:00+08:00
published_at: 2026-07-16T18:16:26+08:00
published_at_raw: "2026-07-16 18:16:26"
published_precision: datetime
retrieved_at: 2026-07-16T18:25:00+08:00
event_date: 2026-07-16
paper_id: 2607.06560v1
paper_pdf: /sources/papers/2026-07-16/2607.06560v1.pdf
paper_pdf_url: https://arxiv.org/pdf/2607.06560v1.pdf
paper_pdf_sha256: c2d3387e7e73867be90a32602889cd6008f76ce93e1279bd9596d50269aed79a
---

# What happened

商汤科技发布并全面开源「日日新 SenseNova-Vision」理解生成统一视觉大模型。据同步发布的技术报告（arXiv:2607.06560），该模型以单一架构统一了结构化视觉理解、稠密几何预测、图像分割与多视角 3D 几何四大经典视觉任务，不再为每个任务设计专属模型头。商汤同期开放模型权重、代码、训练配方及包含 5000 万条样本的开源视觉语料库。据智东西报道，该模型综合得分登顶 Hugging Face Any-to-Any Leaderboard（全模态任意输入输出开源模型榜单）全球第一，在与 Vision Banana、Youtu-VL 等模型的可比指标上取得领先。

# Why it matters

传统视觉 AI 长期依赖「模型拼盘」——检测、分割、深度、3D 重建各用独立专家模型，系统割裂、部署成本高。SenseNova-Vision 将数十年计算机视觉积累以统一多模态生成方式接入通用基础模型，使视觉感知成为大模型原生能力，并开源完整训练链路，有望降低复杂开放场景视觉应用的研发与部署门槛。商汤称其连续十年蝉联中国视觉 AI 市场份额第一。

# Evidence and caveats

- 一手来源：商汤技术报告 arXiv:2607.06560；Hugging Face 模型集合与 GitHub 代码仓库均已公开。
- 榜单排名来自 Hugging Face Any-to-Any Leaderboard，为公开可查；具体数值以官方榜单实时为准。
- 参数规模、训练数据量等细节以技术报告为准；智东西为二手报道，已对照官方链接核实。
- 性能对比基于厂商公布的评测，属 vendor claim，需社区独立复现。

# Citations

1. [商汤技术报告 arXiv:2607.06560](https://arxiv.org/abs/2607.06560)
2. [Hugging Face 模型集合](https://huggingface.co/collections/sensenova/sensenova-vision)
3. [GitHub: OpenSenseNova/SenseNova-Vision](https://github.com/OpenSenseNova/SenseNova-Vision)
4. [智东西报道（2026-07-16 18:16）](https://www.163.com/dy/article/L1VR7A61051180F7.html)
