---
type: Reference
title: 腾讯升级发布具身智能全栈方案，WorkBuddy 推出独立 App 版
description: 腾讯 2026-07-18 在 WAIC 升级发布贯穿云底座—模型层—平台层—应用层的具身智能全栈方案，并发布 WorkBuddy 独立 App（业界首个登陆 iOS/Android/鸿蒙三端的通用智能体应用）。
resource: https://dy.163.com/article/L24O7K4V0553DXPD.html
tags: [ai-news, embodied-ai, agents, tencent, product-launch]
timestamp: 2026-07-18T18:25:00+08:00
published_at: 2026-07-18T16:02:31+08:00
published_at_raw: "2026-07-18 16:02:31 来源：电厂"
published_precision: datetime
retrieved_at: 2026-07-18T18:25:00+08:00
event_date: 2026-07-18
---

# What happened

- 2026-07-18 在 2026 世界人工智能大会（WAIC）上，腾讯面向具身智能与智能体领域带来多项产品技术升级发布，首次系统性展示具身智能全栈布局。
- 具身模型矩阵：Hy-Embodied-VLA-0.5（视觉—语言—动作统一建模，超万小时高精度数据训练，跨本体部署能力）、Hy-Embodied-VLM-1.0（感知模型，以仅 1/10 的计算量达到上一代旗舰模型性能）、Hy-Embodied-RxBrain-1.0（认知大脑，首创将文本推理与视觉想象在连续认知序列中深度协同，为决策提供高维指导）。
- 具身智能体：同步发布 TairosAgent 具身智能体框架与 Apexio 智能体，可将「左右脑」「大脑」「小脑」与身体整合成完整系统；于 2025 年发布的钛螺丝（Tairos）平台升级，将向行业提供模型、智能体与开发工具等开源能力与服务。
- 基础设施：腾讯云围绕具身智能搭建从算力底座、模型服务到感知交互的三层体系，并携手伙伴打造业内首个云端 EaaS（Embodied-AI-as-a-Service）具身智能服务。
- 企业级：腾讯云企业级智能体开发平台 ADP 4.0 海外版正式上线；发布「十大行业百大场景生态计划」，平台已落地 30 多个行业。
- 个人端：腾讯 WorkBuddy 正式发布独立 App，成为业界首个登陆 iOS、Android、鸿蒙三端的通用智能体应用。

# Why it matters

- 这是腾讯从单点模型能力向「基座模型 → 原生智能体 → 开发平台」全链条的系统级跃升，呼应其「AI 应用从问答式交互走向任务式协作」的判断，也显示大厂正把具身智能从技术展示推向规模化应用。
- 以 1/10 算力持平上代旗舰、跨本体统一部署等 engineering 指标，体现国产具身模型在效率与工程化上的实质进展；WorkBuddy 三端 App 把通用智能体从桌面/网页推向移动操作系统层。

# Evidence and caveats

- 模型矩阵、量化指标与产品清单来自腾讯官方信息经网易「电厂」刊发的报道；属厂商侧发布（vendor-sourced），具体性能以独立复现与官方模型卡为准。
- 「1/10 计算量达到上代旗舰性能」等为厂商对外表述，落地产线表现需以后续基准与第三方评测核验。

# Citations

1. [闪电快讯｜腾讯升级发布具身智能全栈方案，WorkBuddy 推出 App 版（网易/电厂）](https://dy.163.com/article/L24O7K4V0553DXPD.html)
2. [腾讯首次升级发布具身智能全栈布局（上证报经市值风云）](https://www.wogoo.com/sq/t/7324451114d849ab9ed870b557cfd5f3)
