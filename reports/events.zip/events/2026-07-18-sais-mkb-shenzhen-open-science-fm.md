---
type: Reference
title: 上海科学智能研究院开放多模态科学基础模型「神珍」（Monkey King Bang, MKB）
description: 上智院 2026-07-18 向全球开放统一多模态科学基础模型「神珍」，以 Qwen3-VL-8B 为共享主干、约 110 亿参数，在一个模型中处理并生成 DNA/RNA/蛋白质/小分子/气象场/医学影像六类科学数据。
resource: https://finance.sina.cn/2026-07-18/detail-iniifnzu7057826.d.html
tags: [ai-news, open-source, ai4science, foundation-model, multimodal]
timestamp: 2026-07-18T18:25:00+08:00
published_at: 2026-07-18T12:20:00+08:00
published_at_raw: "2026-07-18 12:20 中央广播电视总台央视新闻"
published_precision: datetime
retrieved_at: 2026-07-18T18:25:00+08:00
event_date: 2026-07-18
---

# What happened

- 上海科学智能研究院（上智院）于 2026-07-18 向全球开放科学多模态基础模型「神珍」（Monkey King Bang, MKB），模型总参数约 110 亿，以 Qwen3-VL-8B-Instruct 为共享主干。
- 「神珍」在一个统一模型中支持六类科学数据的理解与生成：DNA、RNA、蛋白质、小分子、地球系统（气象场）与医学影像，并据任务调用相应处理组件，无需在多个彼此独立的领域模型间切换。
- 区别于把科学数据统一转成文本的做法，「神珍」为每类数据设置专门的数据处理通路（原生科学编码器/解码器）：ESM-2（蛋白质）、RNA/DNA ConvFormer、分子图编码器、Swin-ViT 气象塔、基于 SAM 的医学影像路径，分别保留序列先后、原子连接、空间分布与图像局部细节。
- 除文本问答外，模型可直接生成 RNA 序列、可供计算的分子表示（SMILES）、最长 10 天的全球气象场（滚动预报）以及文本提示驱动的医学影像分割结果。

# Why it matters

- 这是科学智能（AI4Science）领域首个将多类异质科学模态在统一模型中同时做到「理解 + 生成」的开源基础模型，试图回答「如何既保留各学科数据差异、又让一个模型学到可共享规律」这一基础问题。
- 评测表现具竞争力：20 项生物序列任务中 9 项取三款参评模型最优、17 项位列前二；医学影像分割（CT/MRI/病理等九类模态、逾十万个图文样本）平均 Dice 91.20，为 7 种参评方法中最优；10 天滚动气象预报在 500hPa 位势高度、2 米温度、海平面气压等指标达到或优于业务级 ECMWF HRES。
- 模型权重与推理代码已在 Hugging Face（sais-org/MKB）、GitHub 与星河启智平台开放，并附示例脚本与配置，可作为系统级科研智能体「大圣」（DaSheng）的超级大脑，降低科学模型复用与共建门槛。

# Evidence and caveats

- 参数规模、架构与基准分数来自上智院经新浪财经刊发的发布说明；权重与代码以 Hugging Face 模型卡（sais-org/MKB，Apache-2.0 + SAM License）为权威一手载体，建议以模型卡与随附技术报告为准。
- 与约 1 万亿参数的 Intern-S1-Pro 逐项比较为各 10 项任务互有胜负，表明参数规模并非科学模型能力的唯一维度；具体下游任务表现以原始评测协议为准。

# Citations

1. [上海科学智能研究院开放多模态科学基础模型「神珍」（新浪财经，含架构与基准）](https://finance.sina.cn/2026-07-18/detail-iniifnzu7057826.d.html)
2. [AI 模型「神珍」开放 能处理蛋白质、天气等六类科学信息（央广网）](https://www.cnr.cn/newscenter/native/gd/20260718/t20260718_527716710.shtml)
3. [sais-org/MKB · Hugging Face（模型权重 + 技术报告）](https://huggingface.co/sais-org/MKB)
