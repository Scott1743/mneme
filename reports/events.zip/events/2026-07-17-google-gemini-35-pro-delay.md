---
type: Reference
title: 谷歌推迟 Gemini 3.5 Pro 发布，Alphabet 股价跌逾 4%
description: 据彭博社报道，谷歌因旗舰模型 Gemini 3.5 Pro 代码生成能力未达内部目标而推迟发布数月，消息致 Alphabet 股价 7 月 16 日收跌约 4.43%。
resource: https://www.163.com/dy/article/L215AACR05198UNI.html
tags: [ai-news, industry, google, gemini, market, model-release]
timestamp: 2026-07-17T18:30:00+08:00
published_at: 2026-07-17T06:32:00+08:00
published_at_raw: "2026-07-17 06:32:05 来源：智通财经（引彭博社）"
published_precision: datetime
retrieved_at: 2026-07-17T18:30:00+08:00
event_date: 2026-07-17
---

# What happened

- 据彭博社（Bloomberg）援引知情人士报道，谷歌已决定推迟旗舰大模型 Gemini 3.5 Pro 的发布，较原计划延后数月。
- 延期主因是模型性能尚未达到内部预期，其中**代码生成（code generation）能力未达公司内部目标**——该领域正成为全球 AI 厂商竞争最激烈的赛道。
- 消息于 7 月 16 日（美东时间）发酵，Alphabet（GOOGL/GOOG）盘中一度跌约 5%，最终收跌 4.43%。
- 谷歌发言人回应称，公司"正持续快速推出多款 AI 模型，同时保持较高的成本效益"，并表示正与合作伙伴测试 Gemini 3.5 Pro、升级版 Flash 及其他模型，同时就模型测试与美国政府展开合作。
- 背景：谷歌 5 月在 Google I/O 首次发布 Gemini 3.5 Pro，原计划随后一个月向更多用户开放，现已被推迟。报道称 OpenAI 与 Meta 近期发布的新模型在代码生成能力上已超越谷歌现有产品。

# Why it matters

- 代码生成已成为本轮大模型竞争的核心战场，谷歌在该环节的滞后直接影响其企业级与开发者市场竞争力。
- 股价反应显示资本市场对"发布节奏落后"高度敏感，反映 AI 模型交付能力正成为巨头估值的关键变量。
- 呼应近期行业从"参数规模"转向"实际应用能力与成本效率"的竞争重心迁移。

# Evidence and caveats

- 核心信源为彭博社报道，经智通财经、新浪财经、财联社等多家中文媒体转载 corroborate；谷歌发言人未否认延期、仅就测试状态作出回应（属公司确认层面的"延期属实"）。
- "代码生成未达目标"等内部细节来自匿名知情人士，属 single-source 报道，未获谷歌独立文档佐证；将"落后 OpenAI/Meta"等竞争性表述视为媒体分析而非谷歌官方结论。

# Citations

1. [智通财经：代码生成能力未达目标 谷歌推迟推出 Gemini 3.5 Pro（引彭博社）](https://www.163.com/dy/article/L215AACR05198UNI.html)
2. [新浪财经：谷歌大跌5%！报道称 Gemini 旗舰模型发布延期，编程能力不及预期](https://cj.sina.com.cn/article/norm_detail?url=https%3A%2F%2Ffinance.sina.com.cn%2Fstock%2Ft%2F2026-07-17%2Fdoc-iniiaair8151416.shtml)
