---
type: Reference
title: Google adds AI image generation to Search AI Overviews
description: Google is rolling out text-to-image generation directly inside Search's AI Overviews, running on Nano Banana 2 Lite; English-language rollout "in coming weeks" across all regions that already support AI-mode image generation. Google Images homepage is also being redesigned with a dynamic gallery and saved-image collections.
resource: https://support.google.com/websearch/answer/16649374
tags: [ai-news, google, search, ai-overviews, image-gen, nano-banana]
timestamp: 2026-07-15T11:45:00+08:00
published_at: 2026-07-14
published_at_raw: "Google adds AI image generation directly into Search's AI Overviews"
published_precision: date
retrieved_at: 2026-07-15T03:46:11Z
event_date: 2026-07-14
---

# What happened

Google is adding AI image generation directly to Search's AI Overviews. When no matching image exists on the web for a query, users can now generate one by typing a prompt into the search bar. The feature runs on Google's new **Nano Banana 2 Lite** model — the speed- and cost-optimized image model released the same day.

Rollout starts in the coming weeks, in English, across every region that already supports image generation in Google Search's AI Mode.

In parallel, **Google Images** is getting a redesigned homepage with a dynamic gallery that pulls content from the web in real time, tailored to each user's interests. Saved images can be grouped into collections, surfaced as tabs above the gallery. The new homepage rolls out in the coming weeks, English-only on desktop in the U.S. initially. A Google account is required.

# Why it matters

Search's AI Overviews were already reshaping the open-web traffic equation by replacing blue-link results with synthesized answers. Adding image generation inside Overviews accelerates that loop: when no image exists for a query, Search stops being a router to image hosts and starts being an image generator. For the open web, that's another cut into the residual traffic that image search still drives to stock-photo and editorial-image sites.

The Google Images homepage redesign layers a personalized feed onto what was previously a relatively neutral entry point, mirroring the kind of curated discovery surfaces already common on TikTok and Instagram — a strategic repositioning of one of the web's highest-traffic landing pages.

# Evidence and caveats

Primary source: Google's own Search support page for AI Overviews (linked as the canonical user-facing resource for AI Overviews features, including the image-generation rollout). Independent: The Decoder (frontpage, 2026-07-14) reports Google's positioning and the "fewer clicks to the open web" framing. Vendor-sourced but fact-rich; treat Google's framing as the company's own framing. Quality score 9, promotional risk 1.

Google's main `blog.google/technology/ai/` page timed out on direct fetch in this run; primary documentation fell back to the Search support article, which is the canonical user-facing resource for AI Overviews features.

# Citations

1. [Google Search support — AI Overviews / image generation](https://support.google.com/websearch/answer/16649374)
2. [Google Images](https://images.google.com/)
3. [The Decoder — Google launches Nano Banana 2 Lite + Gemini Omni Flash (Nano Banana 2 Lite model detail)](https://the-decoder.com/google-launches-nano-banana-2-lite-for-fast-ai-images-and-gemini-omni-flash-for-video-via-api/)
4. [The Decoder — Google CEO says people love AI Overviews and keep coming back to Search more](https://the-decoder.com/google-ceo-says-pichai-says-people-love-ai-overviews-and-keep-coming-back-to-search-more/)