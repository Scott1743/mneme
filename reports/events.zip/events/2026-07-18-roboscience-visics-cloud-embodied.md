---
type: Reference
title: RoboScience 发布 Visics 全球首个云端部署具身大模型，实现「一脑控多手、30 秒换手」
description: RoboScience 机器科学在 WAIC 2026 发布通用具身大模型 Visics，采用自研 VLOA 架构，支持 10+ 款不同品牌灵巧手「一脑多手、换手即用」，并与腾讯云合作打造 EaaS，成为全球首个具备云端部署能力的具身大模型。
resource: https://finance.sina.com.cn/stock/t/2026-07-18/doc-iniieweh1611727.shtml
tags: [ai-news, embodied-ai, robotics, waic-2026, roboscience, cloud, physical-ai]
timestamp: 2026-07-19T11:25:00+08:00
published_at: 2026-07-18T11:45:00+08:00
published_at_raw: "2026-07-18 11:45 来源：新浪财经（机器之心Pro）"
published_precision: datetime
retrieved_at: 2026-07-19T11:25:00+08:00
event_date: 2026-07-18
---

# What happened

- 2026-07-18 WAIC 2026 现场，RoboScience 机器科学首次亮相通用具身大模型 Visics，并以「跨灵巧手操作」压力测试引发关注：同一套模型控制不同灵巧手，拆手、换手到重新开工仅需约 30 秒，无需重新采集数据或现场训练，被称为行业首次「一脑多手、换手即用」。
- Visics 采用自研 VLOA（Vision-Language-Object-Action）架构，其中核心新增 Object Trajectory Token——描述物体在任务中位置、姿态、形变与接触关系的连续 3D 点云轨迹，将任务/硬件/物体三类变量统一到共同表达；上层具身世界模型在三维空间预演物体轨迹，下层通用操作模型把轨迹翻译成当前本体的动作。
- 目前已支持 10 款以上不同品牌灵巧手；多 SKU 抓取成功率稳定 99% 以上；预训练数据来自海量视频 + 仿真，单条数据获取成本降至传统方案 1/20–1/200，已积累数百亿次 Manipulation 操作轨迹，2026 年目标扩展至 1T 规模。
- 与腾讯云达成战略合作，基于腾讯云算力与存储底座打造云端 EaaS（Embodied AI as a Service），通过 API 对外开放 VLOA 架构、Object Trajectory 数据标准、跨本体泛化能力与全自动数据管线，成为全球首个具备云端部署能力的具身大模型。

# Why it matters

- 具身智能交付逻辑可能改变：机器人「智能」开始摆脱对特定硬件与本体的强绑定，从「一台机器人、一套模型、一个项目」走向「卖能力、做平台」的 EaaS 模式，模型统一升级、机器人按需调用，有望降低具身智能进千行百业的门槛。
- 「一脑控多手」与跨本体零样本泛化，直击灵巧手换型需重新采集数据、训练、工程适配的行业痛点，是具身大模型从 Demo 走向可规模化业务的关键一步。

# Evidence and caveats

- 架构、演示细节与数据（99% 抓取成功率、1T 轨迹目标、成本降幅）来自机器之心 Pro 经新浪财经刊发的现场报道，为厂商侧发布（vendor-sourced）且以展台演示为依据；真实复杂场景的泛化与延迟仍需量产与长期运行验证。
- EaaS 上云仍面临延迟、安全、网络稳定与端云协同等现实问题；「全球首个云端部署具身大模型」为厂商表述。

# Citations

1. [全球首个云端具身大模型炸场 WAIC：一脑控多手、30 秒换手（机器之心Pro 经新浪财经）](https://finance.sina.com.cn/stock/t/2026-07-18/doc-iniieweh1611727.shtml)
