---
type: Reference
title: 腾讯混元发布科学发现智能体 Hyra-1.0（递归自我改进）
description: 腾讯混元推出 Hunyuan Research Agent 首个版本 Hyra-1.0，轻量 Harness 下持续循环探索更优方案，在 AI for AI / AI for Science 多项任务刷新公开纪录。
resource: https://hunyuan.tencent.com/
tags: [ai-news, agent, research-agent, tencent, hunyuan, rsi]
timestamp: 2026-07-21T18:25:00+08:00
published_at: 2026-07-21
published_at_raw: "2026年7月21日"
published_precision: date
retrieved_at: 2026-07-21T18:25:00+08:00
event_date: 2026-07-21
---

# What happened

腾讯混元于 2026-07-21 推出 **Hyra-1.0**（Hunyuan Research Agent）首个版本：能递归自我改进（recursive self-improvement）、面向性能导向研究与工程任务的智能体。

设计遵循 **The Bitter Lesson**——框架尽量轻量简单、动作空间尽量广阔。给定任务描述，Hyra 持续运行一个循环：基于历史经验（过去 solution 的运行日志、评估器反馈、solution 源码）探索提出更优方案，直到 Agent 主动结束或预算耗尽，返回历史最优方案。采用"生产者-消费者"异步流水线。

# Why it matters

递归自我改进（RSI）/自动化研究是过去一年最活跃的前沿（Google DeepMind AlphaEvolve、Together AI、Karpathy autoresearch）。Hyra 把进化型系统从封闭基准推向开放科学发现与工业场景，是国产实验室在"AI 做科研"方向的重要落子，也延续了腾讯混元在长上下文（HiLS-Attention）与智能体上的连续投入。

# Evidence and caveats

官方公布多项**可验证结果**（开源至 GitHub）：
- **AI for AI**：NanoChat Autoresearch Validation BPB 降至 0.9015；NanoGPT Speedrun 达 3.28 validation loss 用时 76.4s；SOL-ExecBench 235 个 GPU kernel 联合优化 Mean SOL 0.771——三项均超此前公开记录。
- **AI for Science**：55 个数学开放问题中 29 个刷新历史最好；从 1749–1932 年太阳黑子数据发现预测递推公式，近一个世纪样本外预测 R² 0.77；量子计算中设计的路由算法在 IBM Q20 上相比经典 SABRE 路由效率 +44.4%；药物设计中 PARP1 抑制剂候选分子结合-成药联合评分超已上市药物 olaparib。
- **AI for Fun**：自对弈开发的黑白棋 bot 在 730 个参赛程序中排名第 3；可由单张 2D 图像生成可渲染 3D 模型。

上述基准为**厂商口径**，需独立复现；"递归自我改进"属研究范式表述，实际能力边界以开源代码与第三方测评为准。

# Citations

1. [腾讯混元官方 Research：Hyra](https://hunyuan.tencent.com/)
2. [Hyra 研究博客 hy.tencent.com/research/hyra](https://hy.tencent.com/research/hyra)
3. [凤凰网科技报道（含基准细节）](https://new.qq.com/rain/a/20260721A08O6X00?refer=cp_1009)
