---
type: Reference
title: Hassabis proposes FINRA-style US AI standards body that could coordinate frontier-model slowdowns
description: Demis Hassabis published a proposal for a US AI standards body modeled on financial regulator FINRA, tasked with developing evaluation protocols for frontier models and able to coordinate a slowdown in AI development if needed; startups and research models would be exempt.
resource: https://the-decoder.com/deepmind-ceo-hassabis-says-nobody-in-the-world-knows-what-happens-next-so-cautious-optimism-means-building-guardrails-now/
tags: [ai-news, deepmind, hassabis, policy, ai-governance, finra]
timestamp: 2026-07-15T11:45:00+08:00
published_at: 2026-07-14
published_at_raw: "DeepMind CEO Hassabis says nobody in the world knows what happens next so cautious optimism means building guardrails now"
published_precision: date
retrieved_at: 2026-07-15T03:46:11Z
event_date: 2026-07-14
---

# What happened

Demis Hassabis, CEO of Google DeepMind, has published a sweeping proposal for how to handle advanced AI. The proposal, surfaced on 2026-07-14, calls for a new US standards body modeled on financial regulator **FINRA**, with two operational roles:

- develop **evaluation protocols for frontier AI models**;
- be empowered to **coordinate a slowdown in AI development** if needed.

Startups and research models would be exempt. Hassabis frames the proposal under a "cautious optimism" banner, arguing that "nobody in the world knows what happens next" and that building guardrails now is the responsible move.

# Why it matters

This is the most concrete frontier-lab CEO-level policy blueprint to come out of the current US AI debate. The FINRA analogy is significant: FINRA is a self-regulatory organization with quasi-governmental authority over US broker-dealers. Modeling an AI body on FINRA implies a structure that is **not a federal agency** but is recognized by one, with rule-writing and enforcement teeth for a specific industry segment — the same shape some US AI policy circles have been sketching under "sector-specific regulator" framings.

The "coordinate a slowdown" clause is the newsworthy edge — it's an explicit opt-in mechanism for frontier labs to throttle themselves, which sits in tension with the competitive-race logic that drives frontier-model deployment schedules. Exempting startups and research models is a politically smart carve-out that keeps academic and small-lab work moving and avoids the appearance of cartel-style coordination among incumbents.

The proposal lands alongside Hassabis's own ongoing public stance on AI risk and complements his prior calls for international coordination on advanced-AI safety work.

# Evidence and caveats

**Single-source** in this run: the proposal was carried into coverage by The Decoder (frontpage, 2026-07-14). Hassabis's primary publication URL (DeepMind blog post, interview transcript, or signed essay) was not retrieved in this run; treat Hassabis's quoted language as authentic to him but verify against his primary channel before citing in policy work. Quality score 10, promotional risk 0 (issuer-only via secondary carrier).

Follow-up actions for the next news cycle:

- locate Hassabis's primary publication and add it to `resource`;
- check whether Anthropic / OpenAI / Meta CEOs have publicly aligned with or distanced themselves from the proposal;
- watch for any congressional or executive-branch response (Senate Commerce, OSTP, NSF follow-on statements).

# Citations

1. [The Decoder — DeepMind CEO Hassabis proposes FINRA-style AI standards body](https://the-decoder.com/deepmind-ceo-hassabis-says-nobody-in-the-world-knows-what-happens-next-so-cautious-optimism-means-building-guardrails-now/)
2. [European AI Office — comparative regulatory reference](https://digital-strategy.ec.europa.eu/en/policies/ai-office)
3. [OECD AI — international AI policy observatory](https://oecd.ai/)