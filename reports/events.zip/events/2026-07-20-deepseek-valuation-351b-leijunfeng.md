---
type: Reference
title: DeepSeek 估值超 3510 亿元，创始人梁文锋成 AI 新首富
description: 据开润股份公告披露，DeepSeek 最新估值约 3510 亿元人民币，已启动第二轮融资；彭博亿万富豪指数显示梁文锋身价升至 360 亿美元，成全球 AI 公司领域新首富。
resource: https://weibo.com/7905315703/5322676978582812
tags: [ai-news, business, deepseek, valuation, funding]
timestamp: 2026-07-20T18:25:00+08:00
published_at: 2026-07-20T00:00:00+08:00
published_at_raw: "2026-07-20（上证报/IT之家口径）"
published_precision: date
retrieved_at: 2026-07-20T18:25:00+08:00
event_date: 2026-07-20
---

# What happened

2026-07-20，多方报道称，开润股份一则公告披露人工智能公司 DeepSeek 最新估值约为 3510 亿元人民币，公司已启动第二轮融资，但年底是否冲刺科创板尚不确定。据彭博亿万富豪指数，DeepSeek 创始人梁文锋身价飙升至 360 亿美元，超越 Anthropic 与 OpenAI 联合创始人，成为全球 AI 公司领域新首富。

# Why it matters

DeepSeek 以开源+低成本路线迅速跻身全球 AI 顶层，其超高估值与创始人登顶 AI 首富，标志着中国 AI 创业公司从技术突破走向资本与商业价值的集中兑现，也折射出市场对「开源大模型+中国场景」叙事的强烈认可。

# Evidence and caveats

- 估值源自上市公司公告转述（上证报/IT之家口径），非 DeepSeek 官方披露；科创板冲刺与否未定；
- 属 single-source（公告转述），具体融资条款待核实。

# Citations

1. [AIGC日报 2026-07-20 · DeepSeek 估值超 3500 亿元，梁文锋成 AI 新首富（汇编上证报/IT之家）](https://weibo.com/7905315703/5322676978582812)
