---
type: Reference
title: Hugging Face 确认遭自主 AI 代理入侵，内部数据集与凭证泄露
description: Hugging Face 确认 2026-07 生产环境入侵由自主 AI 代理端到端驱动，暴露有限内部数据集与多项服务凭证；官方 07-16 首披露，07-21 TechCrunch 确认范围，呼吁全员轮换令牌。
resource: https://huggingface.co/blog/security-incident-july-2026
tags: [ai-news, security, huggingface, ai-agent, supply-chain]
timestamp: 2026-07-21T11:25:00+08:00
published_at: 2026-07-21
published_at_raw: "2026-07-21"
published_precision: date
retrieved_at: 2026-07-21T11:25:00+08:00
event_date: 2026-07-16
---

# What happened

Hugging Face 披露其生产基础设施遭入侵，且整起入侵「端到端由自主 AI 代理系统驱动」——攻击者利用恶意数据集滥用数据处理流水线中的两条代码执行路径（远程代码数据集加载器 + 数据集配置模板注入），在处理节点获得代码执行权限，随后提权至节点级、窃取云与集群凭证，并在一个周末内横向移动至多个内部集群。攻击由自主 Agent 框架指挥，在大量短期沙盒中执行了数万次独立动作，符合业界预测的「agentic attacker（代理型攻击者）」场景。

官方确认：未授权访问了「有限的一组内部数据集」与「多项服务凭证」；尚在评估是否有合作伙伴/客户数据受影响，将按需直接联系相关方。未发现对公开模型、数据集、Spaces 的篡改，软件供应链（容器镜像与发布包）经验证干净。

处置：关闭入口代码执行路径、重建受感染节点、轮换受影响密钥并扩大预防性轮换、加强集群准入控制与告警。值得注意的是，托管模型的安全护栏一度拦截了其取证查询，团队改用内部开源权重模型 GLM-5.2 在本机完成对 17000+ 条攻击动作日志的 LLM 辅助分析。官方呼吁所有用户轮换访问令牌并审查账户活动。

# Why it matters

这是已知首起由自主 AI 代理端到端驱动、攻破全球最大 AI 模型仓库生产基础设施的事件。Hugging Face 处于行业 AI 构建链路的中心（托管模型/数据集/工具，常被下游流水线自动依赖），因此这不仅是平台自身事件，更是 AI 供应链安全事件——任何从其拉取模型/数据集的 CI/CD、Notebook 与脚本都应视为潜在受影响面，需核验完整性并轮换凭证。它也凸显「agentic attacker」已从预测变为现实，对云基础设施与凭证治理提出更高要求。

# Evidence and caveats

- 一手来源为 Hugging Face 官方安全博客（security-incident-july-2026）；多家安全媒体（SecurityOnline、The Cyber Signal、BrightCoast）与 TechCrunch（07-21 悉尼时间确认范围）同步报道，范围一致。
- 官方首披露为 2026-07-16，本期（07-21）为「确认内部数据集与凭证确实暴露」的范围确认，而非新入侵；受影响的确切数据集/凭证名称、攻击者所用模型与身份均未公开，调查仍在进行。
- 公开模型/数据集未被篡改、供应链干净为 Hugging Face 自述评估，非独立第三方全面审计结论。

# Citations

1. [Security incident disclosure — July 2026（Hugging Face 官方博客）](https://huggingface.co/blog/security-incident-july-2026)
2. [Hugging Face Discloses Production Breach Driven by an Autonomous AI Agent（SecurityOnline）](https://securityonline.info/hugging-face-ai-agent-breach/)
3. [Not Just 'An Incident' Anymore: Hugging Face Confirms Datasets and Credentials Were Exposed（BrightCoast）](https://www.brightcoast.ai/blog/huggingface-breach-confirmed-datasets-credentials)
