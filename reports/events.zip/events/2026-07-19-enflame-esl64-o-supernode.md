---
type: Reference
title: 燧原科技联合中兴发布云燧 ESL64-O 超节点（OEX 正交无背板+天基算力）
description: 燧原科技联合中兴通讯在 WAIC 2026 发布云燧 ESL64-O 超节点（OEX 正交无背板零线缆互联），并推出 CoPoS 面板级先进封装样品与「天基算力」应用场景，推动国产智算从地面迈向天地协同。
resource: https://new.qq.com/rain/a/20260720A02JB800?refer=cp_1009
tags: [ai-news, ai-infrastructure, semiconductor, supernode, enflame, waic-2026]
timestamp: 2026-07-20T18:25:00+08:00
published_at: 2026-07-20T00:00:00+08:00
published_at_raw: "2026-07-20"
published_precision: date
retrieved_at: 2026-07-20T18:25:00+08:00
event_date: 2026-07-19
---

# What happened

2026-07-19，燧原科技联合中兴通讯在 WAIC 2026 发布云燧 ESL64-O 超节点，采用 OEX 正交无背板零线缆互联架构，并推出 CoPoS 面板级先进封装样品与「天基算力」应用场景，推动国产智算从地面迈向天地协同。

# Why it matters

与同期华为 Atlas 950、阿里灵骏真武 M890、平头哥、奕行 RISC-V 超节点等共同构成 WAIC 2026「国产超节点集体亮相」主线，标志国产 AI 算力竞争从单芯片峰值算力转向系统级互联效率与全栈自主；「天基算力」更将智算基础设施的边界拓展至天地协同。

# Evidence and caveats

- 信息源自腾讯新闻聚合（驱动之家/亿欧等转述），细节有限；OEX 与天基算力的具体指标与落地节奏待厂商补充；
- 属厂商发布。

# Citations

1. [腾讯新闻 · 科技行业每日热点（含燧原云燧 ESL64-O 超节点）](https://new.qq.com/rain/a/20260720A02JB800?refer=cp_1009)
