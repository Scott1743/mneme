---
type: Reference
title: DeepSeek 正式发布并开源 V4（1.6T MoE / 1M 上下文）
description: 2026-07-20 DeepSeek 发布 V4 系列并同步开源：Pro 1.6T MoE(49B激活)/Flash 284B(13B激活)，1M 上下文，DSA 稀疏注意力，MIT 协议开放权重，API 当日可用。
resource: https://api-docs.deepseek.com/news/news260424/
tags: [ai-news, open-source, deepseek, llm, agent, waic-2026]
timestamp: 2026-07-21T11:25:00+08:00
published_at: 2026-07-20
published_at_raw: "2026-07-20"
published_precision: date
retrieved_at: 2026-07-21T11:25:00+08:00
event_date: 2026-07-20
---

# What happened

2026-07-20，DeepSeek 正式发布全新一代系列模型 DeepSeek-V4 的预览版并同步开源。模型按规模分为两档：

- **DeepSeek-V4-Pro**：MoE 架构，总参数 1.6 万亿、激活参数 490 亿，性能比肩顶级闭源模型；在 Agentic Coding 评测中达当前开源模型最佳水平，世界知识测评大幅领先其他开源模型、仅稍逊于 Gemini-3.1-Pro，数学/STEM/竞赛代码超越所有已公开评测的开源模型。
- **DeepSeek-V4-Flash**：总参数 2840 亿、激活 130 亿，推理能力接近 Pro，简单 Agent 任务旗鼓相当，API 更快更省。

两项结构创新：token 维度压缩 + DSA（DeepSeek Sparse Attention）稀疏注意力，实现全球领先的长上下文能力，将 1M 上下文设为官方服务标配，较传统方法大幅降低计算与显存需求。V4 已针对 Claude Code、OpenClaw、OpenCode、CodeBuddy 等主流 Agent 产品适配优化。API 当日上线（`deepseek-v4-pro` / `deepseek-v4-flash`，支持 OpenAI 与 Anthropic 接口、思考/非思考双模式）；开源权重已在 Hugging Face 与 ModelScope 开放，技术报告同步发布。旧接口 `deepseek-chat` / `deepseek-reasoner` 将于 2026-07-24 停用。

# Why it matters

V4 是继月之暗面 Kimi K3（2.8 万亿，07-17）之后国产开放权重模型的又一里程碑，以 1.6T 参数 + 1M 上下文 + MIT 全开源直接对标闭源前沿，延续并将「开源+超大参数+极致性价比」路线推向新高度。其 Agentic Coding SOTA 与对主流 Agent 框架的原生适配，进一步强化开放权重模型在企业级与开发者市场的竞争力，并倒逼前沿闭源模型的定价与开放策略。

# Evidence and caveats

- 一手来源为 DeepSeek 官方 API 文档公告（api-docs.deepseek.com）与中文公告，信息一致；同步有 Hugging Face 权重集合与技术报告 PDF。
- 具体基准数字（如 Codeforces 3206 超过 GPT-5.4）来自聚合信源 AIGC 日报（引慧视AI迹/21世纪经济报道/IT之家），非官方公告原文；官方公告以「开源 SOTA」「比肩顶级闭源」定性，未逐项列榜。
- V4 为「预览版」（Preview），正式 GA 与完整跑分仍待后续；属厂商发布，能力以官方描述为主，待独立复现。

# Citations

1. [DeepSeek-V4 Preview Release（官方 API 文档公告）](https://api-docs.deepseek.com/news/news260424/)
2. [DeepSeek-V4 预览版：迈入百万上下文普惠时代（官方中文公告）](https://api-docs.deepseek.com/zh-cn/news/news260424)
3. [Hugging Face · DeepSeek-V4 权重集合](https://huggingface.co/collections/deepseek-ai/deepseek-v4)
