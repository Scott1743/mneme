---
type: Reference
title: 日本 Noetra 联盟携手英伟达建设国家级 AI 工厂（27,500 块 Rubin GPU）
description: 2026-07-16，日本 Noetra 联盟（索尼/软银/NEC/本田等）宣布与英伟达共建约 140MW、27,500 块 Rubin GPU 的国家级 AI 工厂，服务 FRONTia 物理 AI 计划，获日本政府约 3,873 亿日元首年资助。
resource: https://www.sony.com/en/SonyInfo/News/Press/202607/26-0716E/index.html
tags: [ai-news, infrastructure, sovereign-ai, nvidia, japan]
timestamp: 2026-07-17T11:25:00+08:00
published_at: 2026-07-16
published_at_raw: "2026-07-16（Sony 新闻稿；财联社/Tom's Hardware 报道）"
published_precision: date
retrieved_at: 2026-07-17T11:25:00+08:00
event_date: 2026-07-16
---

# What happened

- Noetra（原"日本 AI 基盘模型开发"，2026-01 由索尼/软银/NEC/本田牵头成立，6 月更名，7 月运营）于 2026-07-16 宣布与英伟达合作建设国家级 AI 计算基础设施。
- 规划约 27,500 块 NVIDIA Rubin GPU + 13,750 块 Vera CPU，组成约 382 台 Vera Rubin NVL72 机架，约 140MW，服务于日本政府 FRONTia 物理 AI 计划。
- 建设 2027 年 4 月启动，2028 年 6 月投入运营；将训练开源多模态基础模型，用于机器人、数字孪生、工业自动化，预训练权重向国内开发者共享。
- 融资与资助：Noetra 获 44 家企业/机构投资；经产省通过 NEDO 首年委托费约 3,873 亿日元（约 24 亿美元），五年最高约 1 万亿日元（约 61 亿美元）。
- 路线图：2026 财年推理基础模型、2028 财年全模态（文本/图像/视频/音频）、2030 财年"Real-world Native AI"（空间感知/物理世界部署）。

# Why it matters

- 被称为全球首个"国家级 AI 工厂"（state-tendered national infrastructure），是日本主权 AI（sovereign AI）与机器人战略的核心，目标 2040 年拿下全球 AI 机器人市场 30%+（约 6 万亿日元）。
- 标志国家层面以 Rubin 平台构建自主物理 AI 能力，与美中形成第三极算力阵营。

# Evidence and caveats

- 一手来源为 Sony 新闻稿与英伟达/Tom's Hardware 报道；成本与时间表部分来自媒体推算（如机架单价、Morgan Stanley GPU 单价），非官方确认。
- 设施 2028 年才投运，Rubin 架构届时成熟度待观察；政府资助含年度阶段评审，全额并非确定。

# Citations

1. [Sony News: Noetra Launches Full-Scale R&D for Japan-Developed Multimodal Foundation Model](https://www.sony.com/en/SonyInfo/News/Press/202607/26-0716E/index.html)
2. [Tom's Hardware: Nvidia and Japan's Noetra consortium to build a 140MW Rubin AI factory with 27,500 GPUs](https://www.tomshardware.com/pc-components/gpus/nvidia-and-japans-noetra-consortium-to-build-140mw-rubin-ai-factory-with-27500-gpus)
3. [财联社：日企 AI 联盟拟采购近 3 万枚英伟达 Rubin 芯片](https://so.html5.qq.com/page/real/search_news?docid=70000021_2366a58ae0c28852)
