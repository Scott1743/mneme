---
type: Reference
title: 文远知行发布物理 AI 认知基础大模型 WeRideWITT
description: 文远知行在 WAIC 2026 发布自研物理 AI 认知基础大模型 WeRideWITT，引入「最小物理事实单元」，将真实场景拆为可验证事实单元，垂类事实错误率约为通用大模型 1/3。
resource: https://m.21jingji.com/article/20260719/herald/92740b862f16360efe202f6a52e377de.html
tags: [ai-news, autonomous-driving, physical-ai, weride, foundation-model, waic-2026]
timestamp: 2026-07-19T18:25:00+08:00
published_at: 2026-07-19
published_at_raw: "发布时间:2026年7月19日"
published_precision: date
retrieved_at: 2026-07-19T18:25:00+08:00
event_date: 2026-07-19
---

# What happened

在 WAIC 2026 上，文远知行（WeRide）发布自研物理 AI 认知基础大模型 **WeRideWITT**，首次引入「最小物理事实单元」概念，将连续变化的真实场景拆解为可被识别和验证的事实单元。模型构建从事实提取、事实推理到事实验证、事实编排的完整链路：以一段夜间雨天城市道路行车视频为例，系统将其拆解为「自车右转」「交叉口」「信号变化」等多个可追溯的事实单元。为避免通用大模型在复杂交通环境中产生幻觉，WITT 从六个维度对模型输出进行交叉验证。

# Why it matters

WITT 是文远知行「物理 AI 飞轮」（与自研世界模型 WeRideGENESIS 共同驱动）的认知底座，直接服务其 L4 自动驾驶。据厂商披露，在自动驾驶垂类场景中，WITT 平均每片段事实错误率约为通用大模型的 **1/3**；相较动辄百亿参数的通用大模型，同类任务可节省 **98% 的 Token 成本**，单卡单日可处理 1 万分钟车辆运行视频，数据处理效率最高提升 **200 倍**。依托该能力，文远知行在阿布扎比的 Robotaxi 已覆盖 70% 核心城区。这反映自动驾驶企业正从「堆参数」转向以「可验证事实单元 + 低成本推理」为核心范式的物理 AI 基础模型路线。

# Evidence and caveats

- 报道来自 21 世纪经济报道（2026-07-19，WAIC 现场），属单一主流媒体报道，具体指标均为厂商（文远知行）披露，未见第三方独立复现。
- 「1/3 错误率」「98% Token 节省」「200 倍效率」等为厂商口径，宜视为待独立验证的宣称。

# Citations

1. [21 世纪经济报道 · WAIC 观察：AI 开始交付了（含 WeRideWITT）](https://m.21jingji.com/article/20260719/herald/92740b862f16360efe202f6a52e377de.html)
2. [新浪财经 · 让答案从对话里走出来：文远知行 WeRideWITT](https://t.cj.sina.com.cn/articles/view/1651428902/626ece2602001gz50)
