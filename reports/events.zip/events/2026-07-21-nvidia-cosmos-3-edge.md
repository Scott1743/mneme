---
type: Reference
title: NVIDIA 发布 Cosmos 3 Edge 边缘世界模型（4B 开放权重）
description: NVIDIA 在 SIGGRAPH 2026 发布 Cosmos 3 Edge：40亿参数开放世界模型，面向 Jetson/RTX/DGX 边缘部署，实时机器人控制 15Hz，VANTAGE-Bench 同尺寸第一。
resource: https://huggingface.co/blog/nvidia/cosmos3edge
tags: [ai-news, world-model, nvidia, physical-ai, robotics, open-source]
timestamp: 2026-07-21T11:25:00+08:00
published_at: 2026-07-21
published_at_raw: "2026-07-21"
published_precision: date
retrieved_at: 2026-07-21T11:25:00+08:00
event_date: 2026-07-21
---

# What happened

NVIDIA 在 SIGGRAPH 2026 期间发布 **Cosmos 3 Edge** 并在 Hugging Face 开放权重。它是 Cosmos 3 世界模型家族（Super 64B / Nano 16B / Edge 4B）的边缘变体，一个 40 亿参数的全模态（omnimodel）开放世界模型，面向内存受限的边缘设备。

关键技术点：
- 混合 Transformer（Mixture-of-Transformers）架构，自回归塔处理视觉/文本推理、扩散塔处理视觉/音频/动作生成，共享多模态注意力，统一「状态—未来—动作」表示。
- 作为后训练世界动作模型（WAM），在机器人控制分辨率（640×360 观测）下实时推理，于 NVIDIA Jetson Thor 上 15Hz 实时控制、每次推理生成 32 个动作；在同类 4B 规模中 VANTAGE-Bench 视觉分析第一，机器人策略学习 SOTA。
- 支持在 DGX Station 上用专有机器人/传感器数据后训练，再部署到 Jetson Thor 做实时控制；亦覆盖自动驾驶场景理解、智能基础设施视觉智能体（交通/公共安防/物流/工业检测）等。
- 可在 NVIDIA Jetson（含新发布的 T2000/T3000）、RTX PRO、DGX、GeForce RTX 上高效推理；推理与后训练框架、配方已在 GitHub 开放。

# Why it matters

Cosmos 3 Edge 把「前沿物理 AI 世界模型」从数据中心下沉到边缘，解决了一直存在的「能力 vs 部署效率」权衡，让机器人、自动驾驶、工业视觉等场景在本地实时完成感知-推理-行动闭环，无需等待云端。它叠加 07-16 发布的 Jetson T2000/T3000 模组，构成 NVIDIA 面向具身智能的端到端开放栈，并籍由 Cosmos Coalition（Agile Robots、Black Forest Labs、Runway、Skild AI 等）推动开放世界模型生态。

# Evidence and caveats

- 一手来源为 Hugging Face 官方博客（nvidia/cosmos3edge）与 NVIDIA 官方博客/技术博客，模型卡、基准与部署路径一致。
- 发布时间以「Now available / 今日发布」口径记为 2026-07-21（SIGGRAPH 2026 同期）；具体精确时刻未披露，取日期精度。
- 基准（VANTAGE-Bench、RoboLab 等）为 NVIDIA 自报，待独立第三方复现；属厂商发布。

# Citations

1. [Introducing Cosmos 3 Edge（Hugging Face 官方博客）](https://huggingface.co/blog/nvidia/cosmos3edge)
2. [At SIGGRAPH, NVIDIA Advances Graphics and Simulation With Agentic and Physical AI（NVIDIA 博客）](https://blogs.nvidia.com/blog/siggraph-news-2026/)
3. [Develop Physical AI Reasoning, World, and Action Models with NVIDIA Cosmos 3（NVIDIA 技术博客）](https://developer.nvidia.com/blog/develop-physical-ai-reasoning-world-and-action-models-with-nvidia-cosmos-3/)
