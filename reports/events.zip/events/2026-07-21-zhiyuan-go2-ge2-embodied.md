---
type: Reference
title: 智元机器人发布具身基座大模型 GO-2 与世界模型 GE-2
description: 智元机器人在 WAIC 2026 发布具身基座大模型 GO-2（动作思维链+异步双系统）与世界模型 GE-2（从世界模拟到世界学习闭环）。
resource: https://new.qq.com/rain/a/20260721A08MLQ00?refer=cp_1009
tags: [ai-news, embodied-ai, world-model, robotics, zhiyuan, waic]
timestamp: 2026-07-21T18:25:00+08:00
published_at: 2026-07-21
published_at_raw: "2026年7月21日"
published_precision: date
retrieved_at: 2026-07-21T18:25:00+08:00
event_date: 2026-07-21
---

# What happened

智元机器人在 WAIC 2026 发布具身基座大模型 **GO-2** 与世界模型 **GE-2**：
- **GO-2**：通过动作思维链（action Chain-of-Thought）与异步双系统，打通任务规划与动作执行。
- **GE-2**：尝试构建从"世界模拟"到"世界学习"的闭环，让机器人（而非世界模型本身）在更接近真实的仿真体系中训练与迭代。

# Why it matters

世界模型是今年 WAIC 具身智能的核心关键词——机器人最大难题是在变化环境中持续做出正确判断（杯子被移动后怎么办、桌面倾斜后怎么办、有人经过怎么办）。GO-2/GE-2 代表国产具身智能从"能干活"迈向"干好活"的基座升级，与同期大晓开悟世界模型 3.1、它石智航 AWE 3.5 共同勾勒"具身原生基座"竞争格局，标志竞争核心从机器人本体转向可连接多种机器人的智能系统。

# Evidence and caveats

信源为 WAIC 收官综述报道（单源转述厂商发布），未见独立技术报告或公开基准；与 2026-07-20 入库的大晓 Kairos 3.1 世界模型为同期不同厂商方案，未合并。属 **single-source** 报道，关键架构主张待厂商技术报告核实。

# Citations

1. [2026WAIC收官，看见物理AI的落地与未来（腾讯新闻）](https://new.qq.com/rain/a/20260721A08MLQ00?refer=cp_1009)
