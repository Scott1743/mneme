---
type: Reference
title: 字节跳动发布 Seed Audio 1.0 音频创作模型
description: 字节跳动 Seed 于 2026-07-20 发布影视级音频创作模型 Seed Audio 1.0，统一框架端到端建模人声/音效/环境声，多语种 MOS 超 3.5，已上线火山方舟。
resource: https://www.donews.com/news/detail/8/6639379.html
tags: [ai-news, audio-generation, bytedance, multimodal, waic-2026]
timestamp: 2026-07-20T18:25:00+08:00
published_at: 2026-07-20T14:57:04+08:00
published_at_raw: "2026-07-20 14:57:04"
published_precision: datetime
retrieved_at: 2026-07-20T18:25:00+08:00
event_date: 2026-07-20
---

# What happened

2026-07-20，字节跳动 Seed 官方发布音频创作模型 Seed Audio 1.0，面向影视级音频创作。该模型在统一框架下端到端建模人声、音效与环境声，支持多要素时间精准编排、音色风格可控且长时稳定、20 余语种自然生成。主观评测显示，多数场景音频可用率达 90% 以上，多语种 MOS 评分普遍超 3.5 分。模型已上线火山方舟体验中心供公众体验。

# Why it matters

音频生成是继文本、图像、视频之后的又一多模态创作关键模态。Seed Audio 1.0 将人声/音效/环境声统一建模并支持时间轴精准编排，直接服务于影视、短剧、游戏与广告的配音与音效生产，降低专业音频制作门槛，也补全了字节在「文/图/视频/音频」多模态创作矩阵的音频一环。

# Evidence and caveats

- 来源为字节跳动 Seed 官方发布，经 DoNews 于 2026-07-20 14:57 报道，信息一致。
- 评测指标为厂商主观评测（可用率、MOS），未提供独立第三方基准或客观指标；具体模型参数、训练数据与架构未披露。
- 属厂商发布，能力以官方描述为主，待独立复现。

# Citations

1. [DoNews · 字节跳动发布 Seed Audio 1.0 音频创作模型](https://www.donews.com/news/detail/8/6639379.html)
