---
type: Reference
title: 阿里云发布灵骏真武 M890 超节点实例与 Agent Native Cloud 智能体原生云
description: 阿里云在 WAIC 2026 day2 发布灵骏真武 M890 超节点实例（64 卡算力单元、公共云首次提供超节点形态 AI 算力），并推出 Agent Native Cloud 智能体原生云及 AgentTeams、Agentic Computer 企业级智能体工具。
resource: https://dy.163.com/article/L25I2T360550B1DU.html
tags: [ai-news, cloud-infra, agent, alibaba, waic-2026, compute]
timestamp: 2026-07-19T11:25:00+08:00
published_at: 2026-07-18T23:32:11+08:00
published_at_raw: "2026-07-18 23:32:11 来源：科创板日报（网易订阅）"
published_precision: datetime
retrieved_at: 2026-07-19T11:25:00+08:00
event_date: 2026-07-18
---

# What happened

- 2026-07-18 WAIC 2026 day2，阿里云发布灵骏真武 M890 超节点实例：提供高速互联、开箱即用的 64 卡算力单元，是阿里云首次通过公共云对外提供超节点（supernode）形态的 AI 算力服务；灵骏超节点实例已于乌兰察布地域开放邀测。
- 阿里云同时发布 Agent Native Cloud（智能体原生的云），并同步推出 AgentTeams、Agentic Computer 等企业级智能体工具，覆盖基础设施、开发平台与云桌面多个维度。
- 同场的阿里旗下平头哥开源 T-Head SAIL（真武 AI 芯片底层软件）；截至今年 4 月，真武 AI 芯片累计出货 56 万片，服务 20 多个行业、400 多家客户（该子项已在 2026-07-18-t-head-sail-opensource-supernode 事件页单独收录，此处不重复）。

# Why it matters

- 公共云首次以超节点形态对外供给 AI 算力，叠加「智能体原生的云」与 AgentTeams/Agentic Computer，意味着云厂商把竞争从「卖 GPU 时长」推向「卖 agent-ready 的基础设施与开发平台」，直接服务企业级 agent 规模化部署。
- 与本期 WAIC 上国产超节点（华为 Atlas 950、沐曦曦景 S600、中兴 OEX 等）集中亮相相呼应，国产算力竞争正转向系统级全栈效率。

# Evidence and caveats

- 产品形态、规格（64 卡单元、乌兰察布邀测）与工具列表来自阿里云官方信息经科创板日报刊发的报道，属厂商侧发布（vendor-sourced）；实际互联带宽、单卡型号与定价未在本轮公开稿中给出。
- 本事件聚焦灵骏真武 M890 超节点与 Agent Native Cloud，不覆盖同期平头哥 SAIL 开源（已单列）。

# Citations

1. [WAIC 2026 day2：大厂竞发新品，AI 快步「走入」物理世界（科创板日报 经网易）](https://dy.163.com/article/L25I2T360550B1DU.html)
