---
type: Reference
title: Chance AI 发布视觉推理智能 Chance Vision 1.5，MMMU-Pro 公开榜 SOTA 86.9%
description: 视觉智能公司 Chance AI 在 WAIC 2026 发布新一代视觉推理智能 Chance Vision 1.5，MMMU-Pro 官方公开榜综合准确率 86.9% SOTA，定位 Camera-First Visual Agent，从「识图」走向理解意图并行动。
resource: https://new.qq.com/rain/a/20260719A04KK800?refer=cp_1009
tags: [ai-news, vision, multimodal, agent, chance-ai, waic-2026]
timestamp: 2026-07-19T11:25:00+08:00
published_at: 2026-07-19T11:12:00+08:00
published_at_raw: "2026-07-19 11:12 来源：环球网（腾讯新闻）"
published_precision: datetime
retrieved_at: 2026-07-19T11:25:00+08:00
event_date: 2026-07-18
---

# What happened

- 2026-07-18 WAIC 2026 期间，视觉智能公司 Chance AI 发布新一代视觉推理智能 Chance Vision 1.5，并集中展示 Chance AI App 与以摄像头为入口的 Camera-First Visual Agent 技术路径。
- Chance Vision 1.5 在高难度多模态理解与推理基准 MMMU-Pro 官方公开榜单取得 SOTA，综合准确率达 86.9%；MMMU-Pro 覆盖工程图、地图、图表与化学结构等复杂视觉材料，并通过删除不依赖图片即可作答的问题、增加干扰项与加入 Vision-only 设置来考察结合视觉信息的复杂推理。
- Chance AI 将能力概括为三层：复杂视觉理解与推理；基于个人上下文的意图理解（结合长期画像、近期关注与历史事实）；记忆驱动的工具调用与行动（自主选择工具、生成查询、整合多步结果并形成建议或下一步行动）。
- 定位从传统「图片里有什么」延伸到「它为什么与你有关、下一步该做什么」；App 为第一阶段（旅行/消费/收藏/审美/生活问答），中期计划延伸至视觉密集的生产力工具与垂直行业，长期探索与机器人、智能眼镜、可穿戴设备结合。

# Why it matters

- 代表「视觉 Agent」范式：不止识别物体，而是结合用户长期上下文理解意图并驱动工具调用与后续行动，把多模态模型从「识图问答」推向「以摄像头为入口的个人/产业智能体」。
- MMMU-Pro 为公开榜单，86.9% SOTA 可被独立核验，是本期少有的带可复核基准的视觉模型发布。

# Evidence and caveats

- 模型能力、基准分数与路线来自 Chance AI 官方信息经环球网刊发的报道，属厂商侧发布（vendor-sourced）；MMMU-Pro 分数为厂商自报并登榜，建议以榜单实时排名与独立复测交叉核验。
- 「最大」「SOTA」等表述随榜单更新可能变化；长期硬件结合路线尚属规划。

# Citations

1. [WAIC 2026：Chance AI 发布新一代视觉推理智能（环球网 经腾讯新闻）](https://new.qq.com/rain/a/20260719A04KK800?refer=cp_1009)
