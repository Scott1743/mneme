---
type: Reference
title: 奕行智能于 WAIC 2026 发布业界首个 RISC-V AI 算力超节点
description: 奕行智能在 WAIC 2026 发布业界首个 RISC-V AI 算力超节点，基于自研 Epoch 云端 AI 芯片与 ELink 高速互联（单芯 3.2T、正交无背板零线缆），构建从单芯片到十万卡级全国产全栈 AI 算力体系，第一代已量产。
resource: https://www.36kr.com/p/3903359692342918
tags: [ai-news, ai-infrastructure, risc-v, supernode, semiconductor, waic-2026]
timestamp: 2026-07-20T18:25:00+08:00
published_at: 2026-07-20T14:18:00+08:00
published_at_raw: "2026-07-20 14:18:00"
published_precision: datetime
retrieved_at: 2026-07-20T18:25:00+08:00
event_date: 2026-07-20
---

# What happened

2026 世界人工智能大会（WAIC）期间，RISC-V 云端 AI 算力领导者奕行智能正式发布业界首个 RISC-V AI 算力超节点。该超节点基于自研 Epoch 云端大算力 AI 芯片（国内首颗量产的 RISC-V AI 云端大算力芯片，支持分块量化 FP8）与 ELink 高速互联架构，融合正交无背板创新架构、整机液冷等核心技术，构建从单芯片到十万卡级集群的全国产全栈 AI 算力体系。架构层面：单芯互联带宽 3.2T，零线缆设计将互联成本降低 80%、信号完整性提升 30%，传输时延百纳秒级，机房 PUE 优化 20%；单机柜支持 64–128 颗 Epoch 全对等 Scale-Up，单 PoD 可容纳上万卡，集群可平滑扩容至十万卡。软件栈 EVACA Tile 兼容 PyTorch/vLLM/SGLang，KernelFab 将算子开发周期由周级压缩至天级。第一代超节点已实现量产；公司规划一年一代迭代，三年系统综合性能提升 400 倍，并落地全球首套全栈 RISC-V 万卡超节点「AI Token 工厂」。

# Why it matters

在大模型推理与智能体并发需求爆发、单芯片工艺逼近物理上限的背景下，行业竞争从「单芯片峰值算力」升级为「系统综合效率+全栈自主可控」。奕行以 RISC-V 开放指令集切入超节点，是全球首个全链路全国产 RISC-V 超节点，标志着国产算力从「单点芯片」走向「系统级、可规模化」的自主 AI 基础设施，对降低单位推理成本、规避外部供应链风险具有战略意义。

# Evidence and caveats

- 关键指标（3.2T 带宽、PUE 优化 20%、成本降 80%）为厂商披露，未提供独立第三方测试；「十万卡」「400 倍」为规划目标而非已交付状态。
- 属厂商发布。

# Citations

1. [36氪 · 奕行智能于 WAIC 2026 发布业界首个 RISC-V AI 算力超节点](https://www.36kr.com/p/3903359692342918)
