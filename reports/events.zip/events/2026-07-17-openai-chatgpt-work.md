---
type: Reference
title: OpenAI 推出 ChatGPT Work 生产力智能体平台，正面挑战 Workspace / 365
description: OpenAI 推出 ChatGPT Work 长周期任务智能体，可跨应用与文件生成文档/表格/演示/报告/站点，整合 GPT-5.6 与 Codex，被媒体称为面向 Google Workspace 与 Microsoft 365 的"替代型数字员工"。
resource: https://openai.com/zh-Hans-CN/products/release-notes/
tags: [ai-news, openai, product, productivity, agents]
timestamp: 2026-07-17T18:30:00+08:00
published_at: 2026-07-17
published_at_raw: "OpenAI 官方发布说明 2026-07-09 GA；2026-07-16–17 多家媒体以「AI 办公大战」集中报道"
published_precision: date
retrieved_at: 2026-07-17T18:30:00+08:00
event_date: 2026-07-09
---

# What happened

- OpenAI 在发布说明中正式推出 **ChatGPT Work**：一款面向长周期、高复杂度任务的智能体，可研究分析信息、跨已连接应用与文件操作，并生成成品文档、电子表格、演示文稿、报告及 Sites（交互式网站）。
- 运行期间用户可随时跟进进度、调整方向并审批关键操作；并通过定时任务（Scheduled Tasks）持续推进项目。
- Work 整合 GPT-5.6 模型族（Sol / Terra / Luna）与 Codex 引擎；官方 GA（通用可用性）时间为 2026 年 7 月 9 日，向除 Free 与 Go 之外的付费套餐逐步推出。
- 7 月 16–17 日，钛媒体 Edge AI Daily 等以"OpenAI 向 Google 微软腹地开火""AI 办公大战进入全面竞争阶段"集中报道，称其直接挑战 Google Workspace（超 30 亿用户）与 Microsoft 365（4.5 亿商业席位）。
- 同期 OpenAI 将 App Directory 替换为 Plugin Directory，并把 Chat、Work、Codex 合并进新的 ChatGPT 桌面端应用。

# Why it matters

- 标志 AI 智能体从"对话助手"向"替代型数字员工"的战略转型，正式切入企业生产力套件这一最大软件市场。
- 与 Anthropic Claude Cowork（辅助型）、Google Gemini Spark（软集成）形成三强格局，推动 AI 生产力工具从试点走向规模化落地。

# Evidence and caveats

- GA 与功能描述来自 OpenAI 官方发布说明（一级信源）；"AI 办公大战""挑战 Workspace/365"等竞争性表述来自钛媒体等媒体分析，属媒体解读。
- 文中定价（输入 $5/百万 token、输出 $30/百万 token，企业订阅最高 $100/月）来自媒体报道，非 OpenAI 官方统一清单，可能随套餐变动。

# Citations

1. [OpenAI 官方发布说明：隆重推出 ChatGPT Work](https://openai.com/zh-Hans-CN/products/release-notes/)
2. [钛媒体 Edge AI Daily 早报（7月17日）：OpenAI 向 Google 微软腹地开火](https://www.tmtpost.com/8068104.html)
