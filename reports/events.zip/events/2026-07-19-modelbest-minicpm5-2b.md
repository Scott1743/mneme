---
type: Reference
title: 面壁智能发布端侧模型 MiniCPM5-2B（4B 以下 AA 全球第一，512K 上下文）
description: 面壁智能联合 OpenBMB 在 WAIC 2026 发布端侧模型 MiniCPM5-2B（2B 参数），Artificial Analysis 4B 以下模型榜 17 分登顶，原生混合思考+512K 上下文，已完成 9 款芯片 Day0 适配，近期开源。
resource: https://www.163.com/dy/article/L27UH28T0511B8LM.html
tags: [ai-news, on-device, open-source, modelbest, edge-ai, waic-2026]
timestamp: 2026-07-20T18:25:00+08:00
published_at: 2026-07-19T21:48:07+08:00
published_at_raw: "2026-07-19 21:48:07"
published_precision: datetime
retrieved_at: 2026-07-20T18:25:00+08:00
event_date: 2026-07-19
---

# What happened

2026-07-19，面壁智能联合 OpenBMB 在 WAIC 2026 发布最新端侧模型 MiniCPM5-2B。官方表示，在 Artificial Analysis（AA）榜单评测中，MiniCPM5-2B 以 17 分占据榜首，取得全球 4B 以下模型最高得分。模型原生支持混合思考（快速响应与深度推理切换），提供 512K 超长上下文窗口（单次可处理整本长篇小说或数十万行代码），能力覆盖通用知识、数学与代码推理、复杂指令遵循、多语言、长文本、工具调用与深度搜索。训练含 200B 规模 Agent Midtraining、百万条高质量轨迹 Agent SFT 与可扩展 Agent RL 对齐。众智 FlagOS 社区已完成其在华为昇腾、海光、昆仑芯、沐曦、摩尔线程、平头哥、清微智能、天数智芯、英伟达共 9 款芯片的 Day0 适配，并延伸至 ARM 端侧；面壁亦完成对 AMD、英特尔、联发科、高通的端侧适配。模型将于近期在 Hugging Face、魔搭等平台开源。

# Why it matters

端侧小模型是「本地隐私+离线可用+低时延」AI 助手的关键载体。MiniCPM5-2B 以 2B 参数取得 4B 以下全球第一，并一次性打通混合思考、512K 长上下文与 9 款国产+国际芯片 Day0 适配，显著降低端侧智能体在手机、PC、智能座舱落地的工程门槛，也体现国产 AI 生态「模型—芯片—框架」协同适配的成熟度。

# Evidence and caveats

- AA 17 分为厂商引用榜单，具体评测设置待独立复现；「全球第一」限于 AA 4B 以下分组。
- 开源时间厂商称「近期」，具体日期未定；属厂商发布。

# Citations

1. [IT之家/网易 · 面壁智能发布端侧模型 MiniCPM5-2B，完成多款芯片适配](https://www.163.com/dy/article/L27UH28T0511B8LM.html)
2. [同花顺 · 面壁智能发布 2B 参数端侧模型 MiniCPM5-2B，4B 以下性能登顶全球第一](https://stock.10jqka.com.cn/20260719/c678275231.shtml)
