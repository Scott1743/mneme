---
type: Reference
title: 商汤发布日日新 SenseNova U1 Pro 原生多模态智能体基座
description: 商汤在 WAIC 2026 发布面向长程任务的交付级原生多模态智能体基座 U1 Pro，以 NEO-unify 统一架构将理解/生成/行动纳入同一表征空间。
resource: https://k.sina.com.cn/article_5952915705_162d248f906703f3d4.html
tags: [ai-news, model-release, multimodal, agent, sensetime, waic]
timestamp: 2026-07-21T18:25:00+08:00
published_at: 2026-07-21
published_at_raw: "2026年07月21日18:03"
published_precision: datetime
retrieved_at: 2026-07-21T18:25:00+08:00
event_date: 2026-07-21
---

# What happened

商汤在 WAIC 2026 发布日日新 **SenseNova U1 Pro**——面向长程任务的交付级原生多模态智能体基座模型，将理解、生成、行动纳入统一能力框架。

技术基石 **NEO-unify 原生统一架构**让理解/生成/编辑共享同一套表征空间：核心设计包括支持输入与输出近乎无损的视觉接口、采用原生 MoT（Mixture-of-Transformer）架构协同视觉理解与生成，并在统一学习框架中分别以自回归交叉熵训练文本、以像素流匹配训练视觉。其定位"Agentic Creation（智能体创作）"范式——围绕复杂目标持续理解、规划、生成、检查、修正，最终交付可直接使用的结果。

# Why it matters

行业长期受"搭积木"式多模态架构困扰：理解、生成、编辑、行动分散在不同专家模块，任务链越长信息衰减越严重（"听懂了但画不对""改了局部破坏全局"）。U1 Pro 与 WAIC 前夕开源的 SenseNova-Vision（将目标检测、图像分割、深度预测、三维重建沉淀为通用大模型原生能力）共同标志商汤卡位下一代原生统一多模态基座——上层交付级创作（U1 Pro）+ 底层物理世界感知与几何表达（Vision）。

# Evidence and caveats

报道来自机器之心（经新浪转载）对 WAIC 官方发布的解读；性能与架构能力为**厂商口径**，未见独立基准。SenseNova-Vision 开源视觉大模型已于 2026-07-16 入库（见 [2026-07-16 digest](/news/digests/2026-07-16.md)），两者互补、未合并。

# Citations

1. [机器之心 / 新浪：多模态迎来「架构换代」：商汤连出两张牌](https://k.sina.com.cn/article_5952915705_162d248f906703f3d4.html)
