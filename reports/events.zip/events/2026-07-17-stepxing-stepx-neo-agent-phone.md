---
type: Reference
title: 阶跃星辰在 WAIC 首秀智能体原生手机 STEPX Neo 与操作系统 Step AOS
description: 阶跃星辰于 2026-07-17 在 WAIC 2026 首秀大模型原生智能体手机 STEPX Neo（获"镇馆之宝"），搭载智能体原生操作系统 Step AOS 与个人智能体阶跃 Amoo。
resource: https://k.sina.com.cn/article_5953190046_v162d6789e06703jje6.html
tags: [ai-news, product-launch, agent-os, stepxing, smartphone, embodied-ai]
timestamp: 2026-07-18T11:25:00+08:00
published_at: 2026-07-18
published_at_raw: "2026-07-18 发布于新浪财经（财闻）；事件发生于 2026-07-17 WAIC 开幕日"
published_precision: date
retrieved_at: 2026-07-18T11:25:00+08:00
event_date: 2026-07-17
---

# What happened

- 阶跃星辰在 2026 世界人工智能大会（WAIC 2026）开幕日（7 月 17 日）公开亮相首款大模型原生智能体手机 STEPX Neo，并获本届大会"镇馆之宝"称号。
- 该机搭载智能体原生操作系统 Step AOS（Agentic-native OS），并非在 Android 上叠加 AI 助手，而是围绕智能体从底层重新设计系统架构。
- 内置个人智能体阶跃 Amoo，具备记忆、决策与执行、安全三大核心特征，可将用户多步骤需求拆解为连续任务跨应用执行（如调用携程规划机酒、调用支付宝下单）。
- 已通过首批《人工智能终端智能化分级》系列国家标准 L3 级别测试；与携程、支付宝、滴滴、美团等首批生态伙伴达成 AI 深度合作。
- 董事长印奇表示阶跃只做"大模型原生的 AI 终端"，硬件已就绪将尽快上市，第一阶段不单纯追求出货量而重用户反馈飞轮。

# Why it matters

- 代表 AI 手机竞争从"模型问答/生图"转向"以智能体操作系统重构终端"，是 Agent 从软件走向硬件载体的标志性产品化尝试。
- Step AOS 的"可信、可见、可控、可逆"安全框架（含行为回溯/可反悔）回应了智能体"权限悖论"，为端侧 Agent 落地提供可参考范式。

# Evidence and caveats

- 事实来自新浪财经（财闻）、每日经济新闻、腾讯科技等现场报道；产品定价、上市时间与真实可用性待官方进一步公布。
- 微信未出现在公开合作名单，或成实际落地推广挑战（媒体报道提示）。

# Citations

1. [新浪财经（财闻）：WAIC 2026 阶跃星辰 STEPX Neo 亮相，大模型生态多维协同成亮点](https://k.sina.com.cn/article_5953190046_v162d6789e06703jje6.html)
2. [腾讯科技：如何为 Agent 重构操作系统？我们在 WAIC 看到了答案](https://new.qq.com/rain/a/20260717A0AOAL00)
