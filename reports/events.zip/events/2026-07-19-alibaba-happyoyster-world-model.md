---
type: Reference
title: 阿里云百炼上线开放式世界模型 HappyOyster 1.0（快乐生蚝）
description: 阿里云百炼上线可实时构建与交互的开放式世界模型 HappyOyster 1.0，支持文字/图片生成可探索、可导演的 AI 数字世界，开启灰测。
resource: https://www.163.com/dy/article/L26N72BS0512B07B.html
tags: [ai-news, world-model, alibaba, waic-2026, generative-ai]
timestamp: 2026-07-19T18:25:00+08:00
published_at: 2026-07-19T10:21:05+08:00
published_at_raw: "2026-07-19 10:21:05"
published_precision: datetime
retrieved_at: 2026-07-19T18:25:00+08:00
event_date: 2026-07-19
---

# What happened

2026-07-19，阿里云百炼正式上线开放式世界模型产品 HappyOyster 1.0（快乐生蚝 1.0）。该模型基于海量自然视频学习物理世界状态转移规律，能主动推演从动作到反馈的因果链，并保持人物与环境的长程一致性。提供「世界探索（Adventure）」与「实时导演（Directing）」两大模式：前者输入一句话或一张图即可生成可实时探索、交互的开放世界（支持 1 分钟以上主体动作与环境交互、音画同出）；后者让用户用文字指令实时操控镜头、调度角色、改变剧情走向，画面即时响应，可暂停/改写/回溯。目前已提供 Android / iOS / Web 三端 SDK，在阿里云百炼开启灰测，企业用户与开发者可通过 SDK 与 Open API 快速构建可玩世界、互动剧、AI 陪伴等应用。

# Why it matters

这是国内头部云厂商首次将「可交互、可导演」的世界模型以产品化形态推向开发者，补齐了大模型「实时 3D 交互」短板，标志国内大模型从静态图文/对话生成迈向沉浸式、可交互虚拟世界创作阶段。面向游戏开发、互动短剧、虚拟陪伴与文旅等场景，有望降低中小企业搭建虚拟空间的算力与研发成本，并与阿里云既有的算力与 Agent 基础设施（灵骏真武 M890 / Agent Native Cloud）形成协同。

# Evidence and caveats

- 来源为阿里云官方公众号消息，经每日经济新闻、证券时报、IT之家、DoNews 等多家媒体于 2026-07-19 同日报道，信息一致。
- 当前为灰测（灰度测试）阶段，三端 SDK 已开放；具体模型参数、训练数据规模与基准表现厂商尚未披露，能力评估以官方演示与场景描述为主。
- 属厂商发布，具体技术指标待独立复现。

# Citations

1. [每日经济新闻 · 阿里云百炼正式上线 HappyOyster 1.0](https://www.163.com/dy/article/L26N72BS0512B07B.html)
2. [IT之家/新浪 · 阿里「快乐生蚝」上线，一句话生成可玩世界](https://k.sina.com.cn/article_5952915705_162d248f906703e2po.html)
3. [证券时报 · HappyOyster 1.0 来了，现已登陆百炼](https://www.stcn.com/article/detail/4027472.html)
