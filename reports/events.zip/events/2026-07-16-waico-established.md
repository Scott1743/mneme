---
type: Reference
title: 世界人工智能合作组织（WAICO）在上海成立，29 国签署协定
description: 2026-07-16，29 国代表在上海签署协定，成立独立的政府间国际组织"世界人工智能合作组织"（WAICO），总部设在中国上海，旨在推动 AI 国际合作与全球治理。
resource: https://en.chinadiplomacy.org.cn/2026-07/17/content_118603468.shtml
tags: [ai-news, policy, governance, global, waico]
timestamp: 2026-07-17T11:25:00+08:00
published_at: 2026-07-16
published_at_raw: "2026-07-16（协定签署仪式）；新华社稿件 2026-07-17 发布"
published_precision: date
retrieved_at: 2026-07-17T11:25:00+08:00
event_date: 2026-07-16
---

# What happened

- 2026 年 7 月 16 日，成立世界人工智能合作组织（WAICO）协定签署仪式在上海举行。
- 中共中央政治局委员、外交部长王毅代表中国政府签署协定；哈萨克斯坦、老挝、巴基斯坦、俄罗斯、印度尼西亚等 29 国代表签署，成为创始成员国。
- WAICO 定位为独立的政府间国际组织，总部设在中国上海，遵循《联合国宪章》宗旨，秉持共商共建共享与以人为本原则。
- 目标：促进 AI 国际合作与全球治理，确保 AI 向有益、安全、公平方向发展；围绕科研、技术开发、系统安全与全球治理四个方向合作。
- 联合国秘书长古特雷斯等国家和国际组织代表出席仪式。

# Why it matters

- 首个聚焦 AI 的全球政府间组织，标志 AI 全球治理进入多边制度性合作新阶段。
- 正值 2026 世界人工智能大会（7 月 17–20 日，上海）开幕前夕，凸显全球 AI 治理话语权竞争。

# Evidence and caveats

- 来源为新华社及中国外交部权威发布，属一手官方信源。
- 组织仍处于创始阶段，具体运作机制、成员扩员与治理细则有待后续落地。

# Citations

1. [Xinhua: 29 countries sign agreement on establishing World AI Cooperation Organization (WAICO)](https://en.chinadiplomacy.org.cn/2026-07/17/content_118603468.shtml)
2. [中国外交部：成立世界人工智能合作组织协定签署仪式在上海举行](https://asean.china-mission.gov.cn/zgwj_0/202607/t20260716_11984399.htm)
