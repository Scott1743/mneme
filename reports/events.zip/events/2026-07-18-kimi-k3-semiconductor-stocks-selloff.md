---
type: Reference
title: Kimi K3 开源发布引发 AI 芯片股承压，费城半导体指数本周跌入熊市区间
description: 月之暗面 2026-07-17 发布全球最大开源模型 Kimi K3 后，市场担忧低成本开源模型削弱 AI 芯片与设备商前景，费城半导体指数本周重挫约 10% 并较 6 月高点回落逾 20%。
resource: https://www.163.com/game/article/DK3UFFO400318PFH_mobile.html
tags: [ai-news, market, kimi, moonshot-ai, open-source, semiconductors]
timestamp: 2026-07-18T11:25:00+08:00
published_at: 2026-07-18T08:34:00+08:00
published_at_raw: "2026/7/18 08:34 中央社记者张欣瑜旧金山 17 日电"
published_precision: datetime
retrieved_at: 2026-07-18T11:25:00+08:00
event_date: 2026-07-17
---

# What happened

- 月之暗面（Moonshot AI）于 2026 年 7 月 17 日发布新一代大模型 Kimi K3，以完全开源、低成本与全球最大开源模型之姿亮相，部分编程基准超越 Anthropic Opus 4.8 与 OpenAI GPT-5.5。
- 中央社（台北）7 月 18 日报道，因开源权重可免费下载并按企业数据微调，市场对 AI 芯片与设备商前景产生忧虑，卖压从芯片股扩散至科技股。
- 报道援引《华尔街日报》称，费城半导体指数本周重挫约 10%，创 2025 年 4 月以来最大单周跌幅，且较 6 月高点回落逾 20%，跌入熊市区间。
- 《巴隆周刊》（Barron's）分析认为市场并未因此陷入恐慌，资金系从过度集中的科技股轮动至能源、金融、医疗等板块。
- OpenAI 前瞻策略主管 Dean Ball 在 X 平台指出，Kimi K3 似乎非常耗费 token，实际运行成本未必真低；并认为中国选择开源或源于低估通用人工智能（AGI）风险及自身算力不足。

# Why it matters

- 这是继 2025 年初 DeepSeek-R1 之后，又一个中国开源模型对全球 AI 硬件估值产生直接冲击的例证，显示"低成本开源"正在改变资本市场对算力需求的预期。
- 与 2026-07-17 Kimi K3 模型发布事件（[2026-07-17-kimi-k3-open-source.md](/news/events/2026-07-17-kimi-k3-open-source.md)）互为表里：前者记录技术发布，本页记录其市场外溢效应。

# Evidence and caveats

- 指数跌幅、板块轮动等为中央社援引 WSJ/Barron's 的报道内容；属单信源转述（single-source），指数精确点位与"熊市"判定以原始市场数据为准。
- Dean Ball 的观点为其个人 X 平台发言，属厂商侧人士评论，不代表 K3 真实运营成本定论。

# Citations

1. [中央社（经网易转载）：中国 AI 新模型冲击芯片股 分析：资金轮动 市场未陷恐慌](https://www.163.com/game/article/DK3UFFO400318PFH_mobile.html)
2. [月之暗面 Kimi K3 发布（模型事件页）](/news/events/2026-07-17-kimi-k3-open-source.md)
