---
type: Reference
title: 中国气象局发布「风和」千亿参数级开源气象大模型并启动全球开源计划
description: 中国气象局于 2026-07-17 在 WAIC 气象专会发布人工智能气象服务系统「风和」大语言模型，并启动全球开源计划；其为全球首个千亿参数级开源气象 LLM。
resource: https://ysxw.cctv.cn/article.html?toc_style_id=feeds_default&item_id=13972802967078581964&channelId=1119
tags: [ai-news, open-source, model-release, meteorology, cma, llm]
timestamp: 2026-07-18T11:25:00+08:00
published_at: 2026-07-17
published_at_raw: "2026-07-17 在 2026 世界人工智能大会（WAIC）气象专会发布"
published_precision: date
retrieved_at: 2026-07-18T11:25:00+08:00
event_date: 2026-07-17
---

# What happened

- 中国气象局于 2026 年 7 月 17 日在 2026 世界人工智能大会（WAIC）气象主题分论坛上，发布人工智能气象服务系统「风和」大语言模型，并启动「风和」全球开源计划。
- 「风和」由公共气象服务中心联合雄安气象人工智能创新研究院、智谱等单位研发，是全球首个千亿参数级开源气象大语言模型。
- 基于地球系统数据资源基座，训练了 5000 万 tokens 高质量气象服务语料，集成权威气象数据，并完成生成式人工智能备案。
- 已在 GitHub、Hugging Face、ModelScope 等平台开放完整模型权重，并同步开放标准化 API 接口、云服务与定制化部署方案。
- 国际版已上线并融入气象智能预警方案「妈祖」（MAZU），为全球用户提供中英文智能问答、天气查询与风险分析服务。

# Why it matters

- 首个开源到千亿参数级别的气象垂直大模型，将气象 AI 从闭源/受限服务推向开放共享生态，有望降低全球防灾减灾与早期预警的技术门槛。
- 官方以"完整技术交付方案"（权重+API+云+部署）而非仅权重开放，体现出国产行业大模型开源范式从"放权重"走向"放能力"。

# Evidence and caveats

- 事实来自央视网、中国新闻网、新华社等公开报道及中国气象局相关发布；"全球首个千亿参数级开源气象 LLM"为官方与媒体表述。
- 未获取 GitHub/Hugging Face 上的具体模型仓库 URL 与权重文件大小/许可条款原文，上述以新闻报道为当前主来源；如需核验权重页需后续补抓。

# Citations

1. [央视网：全球首个千亿参数级！「风和」模型全球开源计划启动](https://ysxw.cctv.cn/article.html?toc_style_id=feeds_default&item_id=13972802967078581964&channelId=1119)
2. [中国新闻网：全球首个千亿参数级！「风和」模型全球开源计划启动](https://m.chinanews.com/wap/detail/cht/zw/10661392.shtml)
