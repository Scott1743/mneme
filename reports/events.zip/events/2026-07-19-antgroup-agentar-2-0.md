---
type: Reference
title: 蚂蚁数科发布商业智能体超级工厂平台 Agentar 2.0
description: 蚂蚁数科在 WAIC 2026 正式发布商业智能体超级工厂平台 Agentar 2.0，首批预置 200 个岗位级数字专家模板，提供数百个可订阅的 Skills 级开箱即用智能体工具。
resource: https://dy.163.com/article/L292EPT70534A4SC.html
tags: [ai-news, agent, antgroup, enterprise-ai, waic-2026]
timestamp: 2026-07-20T18:25:00+08:00
published_at: 2026-07-20T08:16:02+08:00
published_at_raw: "2026-07-20 08:16:02"
published_precision: datetime
retrieved_at: 2026-07-20T18:25:00+08:00
event_date: 2026-07-19
---

# What happened

2026-07-19，在 2026 世界人工智能大会（WAIC）上，蚂蚁数科正式发布商业智能体超级工厂平台「Agentar 2.0」。Agentar 2.0 首批预置 200 个岗位级数字专家模板，并提供数百个可订阅的 Skills 级开箱可用智能体工具，面向企业快速搭建与编排业务智能体。

# Why it matters

企业智能体从「单点助手」走向「可批量生产的数字员工工厂」。Agentar 2.0 以「模板+技能市场」降低企业构建专属智能体的门槛，是蚂蚁在金融与企业服务场景将大模型能力产品化、平台化的关键落子，也反映行业从卖模型转向卖「可运营的智能体资产」。

# Evidence and caveats

- 来源为界面新闻 WAIC 报道（2026-07-20 08:16），事件日 2026-07-19。
- 具体架构、底层模型与计费方式厂商未详述；属厂商发布，实际交付能力待企业用户验证。

# Citations

1. [界面新闻/网易 · AI早报：蚂蚁数科发布 Agentar 2.0](https://dy.163.com/article/L292EPT70534A4SC.html)
