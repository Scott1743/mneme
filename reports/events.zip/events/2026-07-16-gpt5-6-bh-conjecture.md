---
type: Reference
title: GPT-5.6 Pro 协助构造反例，证伪 BH 多重检验 FDR 受控猜想
description: 宾夕法尼亚大学沃顿商学院 Edgar Dobriban 利用 GPT-5.6 Pro 在约 90 分钟内构造反例，证明 Benjamini-Hochberg 程序在相关双侧高斯检验下无法保证 FDR 受控，推翻学界默认约 20 年的猜想。
resource: https://arxiv.org/abs/2607.12208
tags: [ai-news, research, openai, gpt-5.6, mathematics, statistics]
timestamp: 2026-07-16T18:25:00+08:00
published_at: 2026-07-14T07:18:00+08:00
published_at_raw: "Submitted on 13 Jul 2026 (23:18 UTC)"
published_precision: datetime
retrieved_at: 2026-07-16T18:25:00+08:00
event_date: 2026-07-16
paper_id: 2607.12208v1
paper_pdf: /sources/papers/2026-07-16/2607.12208v1.pdf
paper_pdf_url: https://arxiv.org/pdf/2607.12208v1.pdf
paper_pdf_sha256: de1db8081da57ddbb5b2af5574a35b90c1a23c0e27fe0d4f9f1dba4209cc45f7
---

# What happened

宾夕法尼亚大学沃顿商学院统计学副教授 Edgar Dobriban 在预印本（arXiv:2607.12208）中证明：Benjamini-Hochberg（BH）多重检验程序在相关双侧高斯 p 值下无法将其假发现率（FDR）控制在名义水平。他构造了一个因子模型，在区间算术证书下严格证明当 α=0.01 时 FDR > 0.0104（对所有足够多的假设数成立），从而推翻学界默认约 20 年的猜想。论文摘要明确写道：「该证明由 GPT-5.6 Pro 取得，并由作者仔细核查。」据 Dobriban 公开的对话记录，GPT-5.6 Sol Pro 约 90 分钟即构造出反例；其前代 GPT-5.5 即便多智能体运行超 20 小时也未能给出有效解法。该结果于 7 月 16 日在中文与英文科技媒体广泛传播。

# Why it matters

BH 程序自 1995 年提出，已被引用超 13 万次，是现代基因组学、临床试验等海量多重检验的「操作手册级」方法。此结果说明在相关数据结构下其 FDR 保护存在被低估的漏洞（尽管实际超出幅度很小，0.104 vs 0.1），对相关领域的统计推断严谨性有直接影响。同时，这是前沿模型产出原创数学/统计结果、而非仅复述已知结论的又一例证，引发对「AI 辅助证明」可靠性的讨论。

# Evidence and caveats

- 一手来源：arXiv:2607.12208，作者为沃顿商学院在职教授，提供完整证明、模拟复现与公开代码（github.com/dobriban/BH）。
- 该结果为预印本，尚未经同行评审；反例的实际影响有限（FDR 超出幅度很小）。
- 「证明由 GPT-5.6 Pro 取得」为作者自述，属 AI 辅助证明，最终由人类作者核查；媒体（新智元、新浪财经、The AI Wrap）于 7/16 报道，细节与作者原帖一致。

# Citations

1. [arXiv:2607.12208 The Benjamini–Hochberg Procedure Can Fail to Control the FDR for Correlated Two-Sided Gaussian Tests](https://arxiv.org/abs/2607.12208)
2. [作者公开代码 github.com/dobriban/BH](https://github.com/dobriban/BH)
3. [新浪财经·新智元报道（2026-07-16）](https://finance.sina.com.cn/wm/2026-07-16/doc-inihycsp7957338.shtml)
