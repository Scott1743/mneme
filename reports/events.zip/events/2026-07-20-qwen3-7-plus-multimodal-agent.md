---
type: Reference
title: 阿里发布 Qwen3.7-Plus 多模态智能体模型（GUI/CLI 混合）
description: 阿里 2026-07-20 发布 Qwen3.7-Plus 多模态智能体模型，统一视觉与语言为单一基座，支持 GUI/CLI 混合操作、视觉编程与自主验证，Vision Arena 全球前五、中国第一。
resource: https://qwen.ai/blog?id=qwen3.7-plus
tags: [ai-news, multimodal, qwen, alibaba, agent, waic-2026]
timestamp: 2026-07-21T11:25:00+08:00
published_at: 2026-07-20
published_at_raw: "2026-07-20"
published_precision: date
retrieved_at: 2026-07-21T11:25:00+08:00
event_date: 2026-07-20
---

# What happened

2026-07-20，阿里通义千问正式发布 Qwen3.7-Plus——将视觉与语言统一为一体化智能体基座的多模态模型。在 Qwen3.7 文本与 Agent 能力基础上，全面升级视觉-语言能力，并保持编码、工具使用与生产力工作流的完整智能体能力。

其核心定位为「多模态交互混合智能体」：可感知真实场景、读取屏幕并操作 GUI、基于视觉参考生成代码、端到端导航移动应用、基于网络知识回答视觉问题，在单一智能体循环中无缝融合 GUI 与 CLI 交互。能力覆盖：多模态 Agent（统一处理图像/视频/屏幕/网页/文本输入）、Visual Agent（视觉理解+代码解释器+搜索增强问答）、Visual Coding（图像/视频生成 SVG、网页与交互前端）、GUI Agent（移动/桌面控件定位与多步操作）、真实场景感知与推理。官方称基于该模型构建的 Hybrid-Agent 系统可连续稳定运行 11 小时以上，自主完成一款 APP 的完整研发闭环。

已在阿里云百炼开放（OpenAI 兼容与 Anthropic 协议），在 Vision Arena 跻身全球前五、中国第一。

# Why it matters

Qwen3.7-Plus 把「能看、能想、能动手」的端到端闭环推向可落地：GUI/CLI 混合操作 + 视觉参考到代码的转化，使其能直接承担前端原型到复杂软件工程乃至真实 APP 开发，是阿里在「多模态 Agent 基座」赛道对标 Kimi K3、 GLM-5.2 等国产前沿的重要落子，也呼应了行业从「聊天模型」向「自主智能体」的整体迁移。

# Evidence and caveats

- 一手来源为 qwen.ai 官方博客与阿里云开发者社区文章，技术描述一致；多家媒体（搜狐、新浪/量子位）同步报道。
- 「11 小时自主开发 APP」「全球前五、中国第一」等来自官方与榜单口径，具体评测设置与基线未逐项公开。
- 注：部分聚合信源将更早的 6 月初预热与此正式发布混谈；本期以 07-20 正式发布/百炼开放为收录节点。属厂商发布，能力以官方描述为主，待独立复现。

# Citations

1. [Qwen3.7-Plus: Multimodal Agent Intelligence（qwen.ai 官方博客）](https://qwen.ai/blog?id=qwen3.7-plus)
2. [Qwen3.7-Plus：想得深，看得懂，做得到（阿里云开发者社区）](https://developer.aliyun.com/article/1739520)
3. [千问正式发布 Qwen3.7-Plus（搜狐科技）](https://www.sohu.com/a/1030977365_384789)
