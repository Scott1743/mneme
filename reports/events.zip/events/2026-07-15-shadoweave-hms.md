---
type: Reference
title: Shadoweave releases HMS holographic memory system, tops LongMemEval and LoCoMo
description: China-based Shadoweave team released HMS (Holographic Memory System), a long-term memory architecture claiming SOTA on LongMemEval (92.8%) and LoCoMo (93.5%); open-source SDK + GitHub.
resource: https://github.com/Shadow-Weave/HMS
tags: [ai-news, memory, agents, long-term-memory, open-source, benchmark]
timestamp: 2026-07-15T18:30:00+08:00
published_at: 2026-07-15T13:33:00+08:00
published_at_raw: "2026-07-15 13:33"
published_precision: datetime
retrieved_at: 2026-07-15T18:25:00+08:00
event_date: 2026-07-15
---

# What happened

- Shadoweave (织影), a team of mostly "00后" researchers from CMU, Tsinghua, Shanghai AI Lab and peer institutions, released **HMS (Holographic Memory System)** — a long-term memory architecture for LLMs/agents that separates *retention* (consolidation) from *recall* (reconstruction).
- Claims SOTA on two long-term-memory benchmarks: **LongMemEval 92.8%** overall (vs prior best Hindsight 88.8%; 94.7% on temporal reasoning, 96.7% on user-preference memory); **LoCoMo 93.5%** (91.5% multi-hop, 95.5% open-domain). Per the report, all compared systems were reproduced from official open repos using GPT-5-mini for extraction/judging.
- A self-evolving controller (HMS-self-evolve) adds +0.4%. Open-source SDK + GitHub repo; positioned as a cross-model, neutral "memory protocol" (Memory Controller).

# Why it matters

- Long-term memory is a known weak spot for agents (context window ≠ memory). A neutral, cross-model memory layer could become shared infrastructure rather than a per-vendor silo. Open benchmarks + SDK make it reproducible and integrable.

# Evidence and caveats

- Claims are team-reported (Shadoweave's own technical report, carried by 新智元). Benchmarks are described as reproducible from open repos, but independent third-party verification is pending. Treat as single-source / vendor-reported until reproduced.

# Citations

1. [GitHub — Shadow-Weave/HMS](https://github.com/Shadow-Weave/HMS)
2. [新智元 report](https://view.inews.qq.com/a/20260715A06BAD00)
