---
type: Reference
title: Thinking Machines Lab releases Inkling, a 975B open-weight multimodal model
description: Mira Murati's Thinking Machines Lab launched Inkling, a 975B MoE model (41B active), 1M context, trained on 45T tokens across text/image/audio/video, under Apache 2.0 open weights — the first Western near-frontier open-weight model in months.
resource: https://thinkingmachines.ai/news/introducing-inkling/
tags: [ai-news, model-release, open-source, multimodal, thinking-machines]
timestamp: 2026-07-16T11:25:00+08:00
published_at: 2026-07-15T09:00:00-04:00
published_at_raw: "July 15, 2026"
published_precision: date
retrieved_at: 2026-07-16T11:25:00+08:00
event_date: 2026-07-15
---

# What happened

- Thinking Machines Lab (founded by former OpenAI CTO Mira Murati) released **Inkling**, its first foundation model, on July 15, 2026.
- **Architecture**: Mixture-of-Experts, 975B total parameters, ~41B active per token, 1M token context window. Pretrained on ~45 trillion tokens across text, image, audio, and video. Uses relative positional embeddings (not RoPE), interleaves sliding-window with global attention at a 5-to-1 ratio.
- **Key features**: calibrated uncertainty flagging (outputs signal when uncertain, rather than hallucinating); adjustable "thinking effort" controls (trade speed for accuracy); native multimodal reasoning across text, image, audio, video inputs (outputs currently text-only including code, styled artifacts, structured data).
- **Benchmarks**: AIME 2026 at 97.1%, GPQA Diamond 87.2%, SWEBench Verified 77.6%. Company explicitly states Inkling is "not the strongest model available today, closed or open" — positioning it as a customizable base model rather than a frontier competitor.
- **License**: Apache 2.0 (full open weights on Hugging Face). Fine-tunable on Thinking Machines' Tinker platform. Served through Together and Fireworks for hosted inference.
- **Bridgewater collaboration**: An open model fine-tuned with Bridgewater's financial expertise scored 84.7% on financial reasoning benchmarks, beating proprietary models at ~14x less cost (per joint evaluation, not independently verified).

# Why it matters

- The open-weight frontier had been dominated by Chinese labs (DeepSeek, Qwen, Kimi, GLM) for ~6 months after Meta pivoted from Llama to closed-source Muse. Inkling is the first Western near-frontier open-weight model in that gap, giving enterprises a credible alternative to Chinese open models for customization and private deployment.
- Positioning as a "fine-tuning-first" base model rather than a "best-in-class" generalist is a deliberate strategy shift: compete on customizability and cost rather than raw capability, aligned with growing industry sentiment (Satya Nadella, Clem Delangue) that production AI will shift to private/open-source alternatives.
- Trained from scratch in under 9 months on Nvidia GB300 NVL72, shorter timeline than OpenAI (~5 years) or Anthropic (~3 years) for first product, signaling a new velocity for well-funded startups.

# Evidence and caveats

- Primary source: Thinking Machines official blog + Mira Murati X post (July 15, 2026). Independent coverage from TechCrunch, SiliconAngle, MIT Technology Review, and multiple Chinese media outlets. Benchmarks are vendor-reported; no independent reproduction yet. Bridgewater results are from joint evaluation, not third-party verified.

# Citations

1. [Thinking Machines — Introducing Inkling](https://thinkingmachines.ai/news/introducing-inkling/)
2. [TechCrunch — Thinking Machines amps up its bet against one-size-fits-all AI](https://techcrunch.com/2026/07/15/thinking-machines-amps-up-its-bet-against-one-size-fits-all-ai-with-its-first-open-model-inkling/)
3. [SiliconAngle — Mira Murati's Thinking Machines drops Inkling](https://siliconangle.com/2026/07/15/mira-muratis-thinking-machines-drops-inkling-open-weights-model-anyone-can-access/)
