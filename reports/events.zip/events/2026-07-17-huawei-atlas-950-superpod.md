---
type: Reference
title: 华为 Atlas 950 SuperPoD 超节点在 WAIC 真机首秀（8192 张昇腾 950DT 互联）
description: 华为 Atlas 950 SuperPoD 超节点在 2026 WAIC 首次真机亮相，以单柜 64 卡为基本单元、最大支持 8192 张昇腾 950DT 芯片高速互联，面向万亿参数大模型训练与推理。
resource: https://weibo.com/ttarticle/p/show?id=2309405321596649996450
tags: [ai-news, compute, huawei, ascend, waic, infrastructure]
timestamp: 2026-07-17T18:30:00+08:00
published_at: 2026-07-17
published_at_raw: "2026-07-17 中国金融网（CFN）报道"
published_precision: date
retrieved_at: 2026-07-17T18:30:00+08:00
event_date: 2026-07-17
---

# What happened

- 在 2026 世界人工智能大会（WAIC，7 月 17 日开幕）上，华为 Atlas 950 SuperPoD 超节点首次真机亮相。
- 据现场报道，这是目前行业规模最大的商用超节点：以单柜 64 卡为基本单元，最大可支持 **8192 张昇腾 950DT 芯片**高速互联，专门为万亿参数大模型的训练与推理设计。
- 同场算力展区还汇集近存计算 3D 芯片、MiniMax M3 多模态大模型、阶跃 Agent 操作系统、全球首款 AI 智能体手机等首发产品；华为 Atlas 950 被多家媒体列为本届"算力底牌"。

# Why it matters

- 国产超节点真机亮相标志着中国高端算力自主化取得阶段性进展，为训练/推理万亿参数模型提供不依赖英伟达集群的本土底座。
- 在谷歌 Gemini 3.5 Pro 延期、算力成为竞争焦点的背景下，国产超节点集群的规模与可用性直接影响国内大模型迭代节奏。

# Evidence and caveats

- 规格（单柜 64 卡、最大 8192 张昇腾 950DT）来自中国金融网（CFN）现场报道与证券时报等媒体一致描述；属厂商展示 + 媒体核实，尚无第三方独立基准测试。
- "最大商用超节点"等为厂商/媒体表述，待会后的独立算力基准（如 SPEC 或第三方实测）进一步验证。

# Citations

1. [中国金融网（CFN）：全球AI巨头扎堆上海，世界人工智能未来之城底牌全面公开](https://weibo.com/ttarticle/p/show?id=2309405321596649996450)
2. [证券时报（搜狐）：今年展区让所有机器人都动了起来（含 Atlas 950 真机揭晓）](https://www.sohu.com/a/1051276559_115433)
