---
type: Reference
title: xAI open-sources Grok Build terminal-native coding agent
description: xAI (SpaceXAI) open-sourced Grok Build, its Rust-based terminal-native coding agent, following a privacy incident where the tool had synced entire user repositories to the cloud regardless of privacy settings. The release enables fully local-first operation.
resource: https://github.com/xai-org/grok-build
tags: [ai-news, open-source, coding-agent, xai, privacy]
timestamp: 2026-07-16T11:25:00+08:00
published_at: 2026-07-15T00:00:00-04:00
published_at_raw: "July 15, 2026"
published_precision: date
retrieved_at: 2026-07-16T11:25:00+08:00
event_date: 2026-07-15
---

# What happened

- On July 15, 2026, xAI (SpaceXAI) **open-sourced Grok Build**, its terminal-native coding agent, publishing the full Rust source code on GitHub (xai-org/grok-build).
- The release follows a **privacy incident**: Grok Build had been syncing entire user code repositories to the cloud, regardless of whether users had toggled privacy settings on. Elon Musk promised "zero anything whatsoever will remain" — all previously uploaded data was permanently deleted, and data retention was disabled going forward.
- The open-source release is the structural fix: users can now **compile and run Grok Build locally** without any cloud dependency, pointing to their own local inference via config.toml.
- **Code coverage**: agent loop (context assembly, response parsing, tool call dispatch), tools (read/edit/search code, run commands), TUI (rendering, input, plan review, inline diff viewer), and extension system (skills, plugins, hooks, MCP servers, subagents).
- Grok Build now runs on **Grok 4.5** (released July 8, 2026). Server-side usage limits have been reset for all users.

# Why it matters

- A structural privacy fix delivered through open-source: by making local-first operation the default, xAI removes itself from the data pipeline entirely — developers can audit exactly what the tool does and verify no data leaves their machine.
- The AI coding agent market is intensifying (Claude Code, Codex, Cursor, Cline, Gemini). Open-sourcing a complete agent framework with MCP server support and subagent delegation is a competitive move to drive adoption by removing friction (usage limits + trust concerns).
- First time xAI has opened a core engineering tool since its founding in 2023, signaling a shift from closed to community-transparent development.

# Evidence and caveats

- Primary source: xAI official blog + GitHub repo (xai-org/grok-build). Independent coverage from CoinDesk, IT之家, Chinaz, 界面新闻. The privacy incident was confirmed by user discovery and Musk's public response. No independent audit of the open-source code yet to verify all cloud sync paths are removed.

# Citations

1. [GitHub — xai-org/grok-build](https://github.com/xai-org/grok-build)
2. [CoinDesk — Grok Build open-sources code and resets usage limits](https://www.coindesk.cc/grok-build-open-sources-code-and-resets-usage-limits-for-users-85798.html)
3. [IT之家 — 上传用户数据事件后，马斯克宣布开源Grok Build](https://www.163.com/dy/article/L1UK27LM0511B8LM.html)
