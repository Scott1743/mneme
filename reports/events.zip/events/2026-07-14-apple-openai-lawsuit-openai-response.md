---
type: Reference
title: Apple v. OpenAI lawsuit escalates; OpenAI says it sees no evidence complaint has merit
description: "On 2026-07-14 OpenAI issued its first public statement about Apple's trade-secrets lawsuit, filed Friday 2026-07-10, that it sees no evidence the complaint has merit. NBC News reports OpenAI did respond to Apple's February outreach before comms stalled over an apparent name mix-up (Wang / Chang)."
resource: https://www.theverge.com/tech/964350/apple-openai-lawsuit-trade-secrets
tags: [ai-news, openai, apple, litigation, trade-secrets, developing]
timestamp: 2026-07-15T10:59:00+08:00
published_at: 2026-07-14
published_at_raw: "OpenAI has a new statement about Apple's lawsuit."
published_precision: date
retrieved_at: 2026-07-15T03:00:00Z
event_date: 2026-07-14
---

# What happened

On 2026-07-14 OpenAI issued a statement responding to Apple's lawsuit filed
Friday 2026-07-10 alleging OpenAI misappropriated hardware trade secrets. The
full OpenAI text: "While we take these allegations seriously, we're not aware
of any evidence that this complaint has merit. We believe in fair competition
and allowing people the freedom to work wherever they choose, and we're
focused on building innovative technology that empowers people everywhere."

Apple's initial complaint, surfaced on 2026-07-13 by The Verge, is a 41-page
filing alleging OpenAI "coached" Apple employees on how to avoid security
checks and asked for "show and tell" during job interviews. NBC News reported
on 2026-07-14 that OpenAI did respond to Apple's February outreach but
communication stopped after one of Apple's lawyers apparently mixed up two
OpenAI staffers with the surnames Wang and Chang.

# Why it matters

This is the first public exchange in what is likely a multi-year hardware-IP
dispute between two companies pursuing on-device AI hardware. The trademark /
trade-secret boundary is the legal fault line: Apple's complaint leans on the
recruiting-process allegations, while OpenAI's response denies substantive
evidence. The Wang/Chang comms mishap is a procedural detail but also a
signal of how legal channels between the two were fraying before filing.

# Evidence and caveats

Primary: Apple's complaint (PDF, 41 pages) and OpenAI's statement as quoted
by The Verge. NBC News independently corroborated the prior-outreach angle.
Treat the case as a developing story — the filings, motions, and Apple's
discovery requests will set the practical scope. Quality score 9,
promotional risk 0.

# Citations

1. [The Verge — Apple v. OpenAI complaint summary](https://www.theverge.com/tech/964350/apple-openai-lawsuit-trade-secrets)
2. [The Verge — OpenAI's 2026-07-14 statement](https://www.theverge.com/news/763022/apple-openai-lawsuit-statement)
3. [NBC News — OpenAI did respond in February](https://www.nbcnews.com/tech/apple/apple-openai-lawsuit-suit-trade-product-hardware-email-sam-altman-rcna587376)
