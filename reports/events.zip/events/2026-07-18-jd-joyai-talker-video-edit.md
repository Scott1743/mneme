---
type: Reference
title: 京东 WAIC 发布 JoyAI-Talker 实时语音交互与 JoyAI-Video-Edit 实时视频编辑模型
description: 京东在 WAIC 2026 day2 发布 JoyAI-Talker 实时语音交互模型与 JoyAI-Video-Edit 实时视频编辑模型，并首次系统展示 JoyAI 模型矩阵、开源行业最大人类视角数据集、打造 JoyInside「AI Home」。
resource: https://dy.163.com/article/L25I2T360550B1DU.html
tags: [ai-news, multimodal, agent, jd, waic-2026, physical-ai, open-data]
timestamp: 2026-07-19T11:25:00+08:00
published_at: 2026-07-18T23:32:11+08:00
published_at_raw: "2026-07-18 23:32:11 来源：科创板日报（网易订阅）"
published_precision: datetime
retrieved_at: 2026-07-19T11:25:00+08:00
event_date: 2026-07-18
---

# What happened

- 2026-07-18 WAIC 2026 进入第二天，京东发布 JoyAI-Talker 实时语音交互模型与 JoyAI-Video-Edit 实时视频编辑模型。
- JoyAI-Talker 具备低延迟对话、情绪理解、工具调用与记忆等能力，目标让 AI 从机械执行指令走向理解人的意图与状态。
- JoyAI-Video-Edit 支持自定义画面与边预览边修改，使视频编辑更实时、灵活。
- 京东首次系统展示面向物理世界的 JoyAI 模型矩阵，开源行业最大人类视角数据集，并打造首个 JoyInside「AI Home」；观众可戴 JoyEgoCam 体验第一视角数据采集。
- 京东探索研究院提出「数字智能→附身智能→物理智能」三阶技术路线（语言/代码/多模态基座 → 部署到手机/电脑/可穿戴/智驾舱 → 部署到真实物理硬件自主完成任务）。

# Why it matters

- 京东以电商巨头的业务场景与供应链为底座押注「物理 AI」，将语言/多模态/具身模型、具身数据采集（JoyEgoCam 第一视角）、云基础设施与全链路业务场景咬合为可迭代闭环，是「AI 从文本软件走向物理世界」主线上的代表性产业布局。
- 开源行业最大人类视角数据集，为具身智能训练提供稀缺的第一视角交互数据，可能降低行业数据门槛。

# Evidence and caveats

- 模型能力、数据集与战略表述来自京东官方信息发布经科创板日报刊发的报道，属厂商侧发布（vendor-sourced）；具体性能与数据集规模待官方技术报告或独立评测佐证。
- 「最大人类视角数据集」为厂商表述，需以实际开放范围与许可核验。

# Citations

1. [WAIC 2026 day2：大厂竞发新品，AI 快步「走入」物理世界（科创板日报 经网易）](https://dy.163.com/article/L25I2T360550B1DU.html)
