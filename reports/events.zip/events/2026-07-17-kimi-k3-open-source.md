---
type: Reference
title: 月之暗面发布 Kimi K3：全球参数最大的开源模型（2.8 万亿）
description: 月之暗面于 2026-07-16 发布 Kimi K3，参数规模 2.8 万亿（MoE），原生支持视觉理解与 100 万 token 上下文，是目前全球参数最大的开源模型。
resource: https://new.qq.com/rain/a/20260717A02W2D00
tags: [ai-news, open-source, model-release, moonshot-ai, llm]
timestamp: 2026-07-17T11:25:00+08:00
published_at: 2026-07-17T09:29:00+08:00
published_at_raw: "2026-07-17 09:29 发布于湖南 潇湘晨报官方账号（财联社 7 月 17 日电）"
published_precision: datetime
retrieved_at: 2026-07-17T11:25:00+08:00
event_date: 2026-07-16
---

# What happened

- 北京月之暗面科技有限公司于 2026 年 7 月 16 日发布新一代基础模型 Kimi K3。
- 参数规模 2.8 万亿，采用 MoE 架构，原生支持视觉理解，具备 100 万词元（token）上下文窗口。
- 官方称其面向软件工程、知识工作、深度研究、多模态理解等复杂任务场景优化。
- 财联社/新华社称其为"目前全球参数最大的开源模型"，综合智能水平仅次于 Claude Fable 5 与 GPT-5.6 Sol（厂商/媒体表述，未经独立基准复核）。

# Why it matters

- 首个突破 2 万亿参数级别的开源模型，标志国产开源大模型进入万亿级生态竞争阶段。
- 对开源社区、本地/私有化部署与全球模型竞争格局具有实质性影响。

# Evidence and caveats

- 参数规模与架构来自月之暗面官方发布及财联社/新华社报道；"全球最大开源模型""仅次于 Claude Fable 5 / GPT-5.6 Sol"为厂商与媒体表述，属 vendor claim，未独立复核基准。
- 未获取月之暗面官方技术博客/模型卡原始 URL；以新闻报道为当前主来源。

# Citations

1. [财联社/潇湘晨报：中国企业发布全球最大规模的开源模型 Kimi K3](https://new.qq.com/rain/a/20260717A02W2D00)
2. [每日经济新闻全球科技早参：月之暗面发布 2.8 万亿参数 Kimi K3（引新华社）](https://so.html5.qq.com/page/real/search_news?docid=70000021_1096a59722a05252)
