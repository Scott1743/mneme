---
type: Reference
title: 马斯克官宣 xAI 训练 2 万亿参数 Grok 4.6（预计下周完成初始训练）
description: 马斯克于 2026-07-18/19 在 X 透露 xAI 正在训练下一代 Grok 4.6（约 2 万亿参数），预计下周完成初始训练，性能全面优于 1.5T 的 Grok 4.5，推理速度接近前代；正式发布时间未定。
resource: https://www.ithome.com/0/978/595.htm
tags: [ai-news, llm, xai, grok, frontier-model]
timestamp: 2026-07-20T18:25:00+08:00
published_at: 2026-07-19T00:00:00+08:00
published_at_raw: "2026-07-19（消息源自 07-18 X 发文）"
published_precision: date
retrieved_at: 2026-07-20T18:25:00+08:00
event_date: 2026-07-19
---

# What happened

2026-07-18，埃隆·马斯克在 X 平台回复网友时透露，xAI 正在训练中的下一代大模型 Grok 4.6 参数规模将达 2 万亿，预计下周完成初始训练。马斯克表示，2T 模型在各方面均优于当前的 1.5T 版本（Grok 4.5），同时推理速度与 Token 效率将接近 Grok 4.5；其猜测「可能会超过月之暗面最新 Kimi K3」。目前 xAI 尚未公布 Grok 4.6 的正式发布时间、训练细节与完整技术指标；模型依托约 20 万块 GPU 的 Colossus 集群训练。

# Why it matters

Grok 4.6 若落地，将进一步推高前沿模型参数规模门槛（2T），并延续 xAI「以更大规模+高推理效率」参与中美大模型军备竞赛的路线；马斯克将其与 Kimi K3 直接对比，也折射出中国开源大模型已成为全球前沿模型的参照系。

# Evidence and caveats

- 为创始人社媒表态，非官方正式发布；模型尚未完成训练、无发布时间与评测指标；
- 「超过 Kimi K3」为马斯克个人猜测；属 developing/single-source，需以 xAI 后续官方发布为准。

# Citations

1. [IT之家 · 马斯克：Grok 4.6 训练进入最后阶段，2 万亿参数模型下周完成初始训练](https://www.ithome.com/0/978/595.htm)
2. [环球网 · 马斯克官宣 2 万亿参数 Grok 4.6 下周完成初始训练](https://cj.sina.com.cn/article/norm_detail?url=https%3A%2F%2Ffinance.sina.com.cn%2Fstock%2Ft%2F2026-07-19%2Fdoc-iniihzci8014857.shtml)
