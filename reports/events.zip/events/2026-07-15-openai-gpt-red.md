---
type: Reference
title: OpenAI discloses GPT-Red, an automated red-teaming model trained via self-play RL
description: OpenAI revealed GPT-Red, an internal automated red team model that achieves 84% attack success rate on novel prompt injection scenarios (vs 13% for human red-teamers), discovering a novel "fake chain-of-thought" attack class.
resource: https://openai.com/index/unlocking-self-improvement-gpt-red/
tags: [ai-news, safety, red-teaming, openai, prompt-injection]
timestamp: 2026-07-16T11:25:00+08:00
published_at: 2026-07-15T09:00:00-04:00
published_at_raw: "July 15, 2026"
published_precision: date
retrieved_at: 2026-07-16T11:25:00+08:00
event_date: 2026-07-15
---

# What happened

- OpenAI disclosed **GPT-Red**, an automated red-teaming model trained via **self-play reinforcement learning** — the same paradigm used for AlphaGo.
- In self-play, GPT-Red (attacker) and a collection of defender LLMs are trained simultaneously. GPT-Red is rewarded for eliciting failures (prompt injection, data exfiltration); defenders are rewarded for resisting attacks and completing original tasks. As defenders improve, GPT-Red must discover stronger attacks.
- **Key results**:
  - On novel (unseen-in-training) indirect prompt injection scenarios against GPT-5.1: GPT-Red achieved **84% attack success rate** vs **13% for human red-teamers** on the same tasks.
  - Against a real-world vending-machine agent (Andon Labs' Vendy): GPT-Red achieved all three malicious objectives — changed an expensive item's price to $0.50, ordered a $100+ item and listed it for $0.50, cancelled another customer's order.
  - Against Codex CLI (GPT-5.4 mini): GPT-Red found more data-exfiltration scenarios than a prompted GPT-5.5 baseline, using fewer tokens.
- **Novel attack class discovered**: GPT-Red found a **"fake chain-of-thought"** prompt injection attack — inserting a fabricated entry into a model's chain-of-thought that tricks it into acting on spoofed information. This attack achieved >95% success on GPT-5.1; after adversarial training with GPT-Red data, the same attack now succeeds <10% on GPT-5.6.
- GPT-Red's attack data was used to train GPT-5.6 Sol, resulting in: GPT-5.6 Sol's prompt injection failure rate reduced to ~0.05% for direct attacks; indirect injection defense accuracy >97% in some scenarios; overall ~6x fewer failures vs previous best production model.
- GPT-Red will **not be released** externally. OpenAI claims it requires substantial compute and is designed to stay stronger than any potential copycat.

# Why it matters

- First credible evidence that AI safety can scale alongside AI capability through automated self-play — turning red teaming from manual spot-checking into systematic coverage.
- The "fake chain-of-thought" attack class is a genuinely novel discovery that human red-teamers had not found, demonstrating that AI attackers can uncover vulnerabilities invisible to current human methods.
- The flywheel design (each attacker generation makes the next defender harder to break) could become the standard approach for frontier model safety, but also concentrates both attack and defense capability within one company.

# Evidence and caveats

- Primary source: OpenAI official blog post (July 15, 2026). Independent coverage from MIT Technology Review (interview with OpenAI researchers), Singularity.Kiwi. Georgetown CSET analyst Jessica Ji confirmed the self-play approach is promising. All performance numbers are from OpenAI's own evaluation; no independent reproduction yet. The Vendy vending machine test was disclosed by OpenAI; Andon Labs has not independently commented.

# Citations

1. [OpenAI — GPT-Red: Unlocking Self-Improvement for Robustness](https://openai.com/index/unlocking-self-improvement-gpt-red/)
2. [MIT Technology Review — Meet GPT-Red: an LLM super-hacker](https://www.technologyreview.com/2026/07/15/1140514/meet-gpt-red-an-llm-super-hacker-openai-built-to-make-its-models-safer)
3. [Singularity.Kiwi — OpenAI Built an AI That Hacks Its Own Models](https://singularity.kiwi/openai-gpt-red-automated-red-teaming-2026)
