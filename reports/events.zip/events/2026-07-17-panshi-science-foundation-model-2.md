---
type: Reference
title: 中科院联合团队发布磐石·科学基础大模型 2.0（通专一体科学智能底座）
description: 中国科学院自动化所牵头、联合十余家院属单位及企业研发的磐石·科学基础大模型 2.0 于 2026-07-17 在 WAIC 发布，采用"通专一体"三层递进架构，60 余项专业科研评测多数超越 GPT-5.5 / Gemini-3.1-pro。
resource: https://epaper.gmw.cn/gmrb/html/content/202607/18/content_19586.html
tags: [ai-news, model-release, scientific-ai, cas, foundation-model, panshi]
timestamp: 2026-07-18T11:25:00+08:00
published_at: 2026-07-17
published_at_raw: "2026-07-17 在 2026 世界人工智能大会暨人工智能全球治理高级别会议首日发布"
published_precision: date
retrieved_at: 2026-07-18T11:25:00+08:00
event_date: 2026-07-17
---

# What happened

- 由中国科学院自动化所牵头、联合十余家院属单位及多家企业协同攻关的磐石·科学基础大模型 2.0（ScienceOne Omni）于 2026 年 7 月 17 日在 WAIC 正式发布。
- 采用"通专一体"技术路径，核心为递进三层架构："科学数据统一编码—自然世界知识对齐—领域任务定向解码"，一个模型即可完成跨学科深度数据理解、可靠知识推理、精准科学预测与专业科研内容生成。
- 依托中国科学院科技语料库联合多所构建 800 万条高质量科学推理数据，覆盖 200 多个科研任务，形成可验证、可追溯的推理链路。
- 在 60 余项专业科研任务评测中，绝大多数显著超越 Gemini-3.1-pro、GPT-5.5 等通用旗舰模型；在化学性质预测、谱到分子结构预测、蛋白质位点预测等任务上领先领域专用模型、达国际最佳。
- 已落地 50 余家中科院内研究所、30 余家院外高校/科研单位/央国企，并走向国际市场；配套"超算+智算+速算"异构算力体系适配昇腾与海光等国产芯片。

# Why it matters

- 是国产"科学基础大模型"从 1.0 到 2.0 的关键升级，试图以统一模型打通通用理解与专业科学能力，缓解"通用模型不专业、领域模型不通用"的痛点。
- 配套一体化科研平台（8000+ 科研工具）与文献罗盘、创新评价等智能体已规模化落地，标志 AI for Science 从单点工具走向平台化科研基础设施。

# Evidence and caveats

- 事实来自光明日报、央视网、中国网等报道；"超越 GPT-5.5 / Gemini-3.1-pro""国际最佳"为研发团队/媒体评测表述，具体基准与测试集以待官方技术报告为准。
- 未获取模型权重/论文/API 的公开 URL，当前以新闻报道为主来源。

# Citations

1. [光明日报：磐石·科学基础大模型 2.0 发布](https://epaper.gmw.cn/gmrb/html/content/202607/18/content_19586.html)
2. [央视网：磐石·科学基础大模型 2.0 发布 开启 AI 赋能基础研究全新范式](https://ysxw.cctv.cn/article.html?toc_style_id=feeds_default&item_id=9174696787834843908&channelId=1119)
