---
type: Reference
title: Xiaomi open-sources Robotics-U0, a 38B unified embodied world foundation model
description: Xiaomi releases Xiaomi-Robotics-U0 (38B params), unifying T2I, image editing, embodied scene generation, transfer, and video generation; code + weights open on GitHub/HF; arXiv 2607.11643.
resource: https://github.com/XiaomiRobotics/Xiaomi-Robotics-U0
tags: [ai-news, open-source, embodied-ai, world-model, robotics, xiaomi]
timestamp: 2026-07-15T18:30:00+08:00
published_at: 2026-07-15
published_at_raw: "2026年7月15日 (news); arXiv submitted 13 Jul 2026; GitHub initial release Jul 13, 2026"
published_precision: date
retrieved_at: 2026-07-15T18:25:00+08:00
event_date: 2026-07-13
paper_id: 2607.11643v1
paper_pdf: /sources/papers/2026-07-15/2607.11643v1.pdf
paper_pdf_url: https://arxiv.org/pdf/2607.11643v1.pdf
paper_pdf_sha256: 01b968b3080e6992746fbf1ae073bdb99e560d6fabab66c4fe31e06ee7212f20
---

# What happened

- Xiaomi Robotics open-sourced **Xiaomi-Robotics-U0**, a 38-billion-parameter multimodal autoregressive world foundation model (initialized from EMU3.5) that unifies five generation tasks under one next-token objective: text-to-image (T2I), image editing (X2I), embodied scene generation, embodied transfer, and embodied video generation.
- Code and weights released on GitHub and Hugging Face / ModelScope (U0 and U0-FlashAR). A technical report and arXiv paper (2607.11643, submitted 13 Jul 2026) accompany the release.
- FlashAR acceleration reaches **5.44 s/img at 1024×1024 on one H20**, 82.86× faster than AR eager decoding.
- Vendor-reported results: **WorldArena #1 for embodied video generation**; improves `pi_0.5` out-of-distribution real-world manipulation success from **36.9% → 63.2%**; outperforms GPT-Image-2.0 on human evaluation of embodied scene generation and transfer.

# Why it matters

- First open model to support high-quality multi-view scene generation across multiple robot embodiments with structured, controllable transfer — positioning it as a reusable "data engine" for scalable robotics training-data production.
- A major Chinese lab open-sourcing a frontier-class embodied world model with fully reproducible artifacts (code, weights, paper, benchmark claims).

# Evidence and caveats

- Primary artifacts verified directly: GitHub repository (LICENSE dated Jul 13, 2026; inference code; weight links), arXiv abstract (2607.11643v1), Hugging Face collections.
- Benchmark numbers (WorldArena, `pi_0.5` OOD) are vendor-reported and not yet independently reproduced. arXiv is a preprint, not peer-reviewed. Video-gen weights are listed as "coming soon."

# Citations

1. [GitHub — XiaomiRobotics/Xiaomi-Robotics-U0](https://github.com/XiaomiRobotics/Xiaomi-Robotics-U0)
2. [arXiv:2607.11643v1](https://arxiv.org/abs/2607.11643)
3. [Hugging Face — XiaomiRobotics/Xiaomi-Robotics-U0](https://huggingface.co/XiaomiRobotics/Xiaomi-Robotics-U0)
