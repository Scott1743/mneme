---
type: Reference
title: China's CAC publishes filing info for 7 mobile on-device generative AI services
description: CAC (网信办) announced 7 newly filed mobile on-device generative AI services including Apple Intelligence (partnering with Alibaba 千问), Huawei Xiaoyi, OPPO AndesGPT, vivo Lanxin, Xiaomi Penghuai, Samsung Galaxy AI, and Nubia Doubao.
resource: https://view.inews.qq.com/a/20260715A085JA00
tags: [ai-news, policy, china, regulation, on-device-ai, cac]
timestamp: 2026-07-15T18:30:00+08:00
published_at: 2026-07-15T16:07:00+08:00
published_at_raw: "财联社7月15日电"
published_precision: datetime
retrieved_at: 2026-07-15T18:25:00+08:00
event_date: 2026-07-15
---

# What happened

- Per the Cyberspace Administration of China (CAC / 网信办), **7 newly filed mobile on-device (端侧) generative AI services** were announced under the *Interim Measures for Generative AI Services*.
- Named services: **Apple Intelligence (苹果智能), Huawei Xiaoyi (华为小艺), OPPO AndesGPT, vivo Lanxin (vivo蓝心), Xiaomi Penghuai (小米澎湃), Samsung Galaxy AI (盖乐世AI), Nubia Doubao (努比亚豆包大模型)** — all 7 now confirmed.
- **Apple Intelligence partners with Alibaba 千问** for Chinese-market AI capabilities; Baidu provides AI visual search for Chinese iPhones. Alibaba US stock rose 6.03% pre-market on the news.
- This is the first dedicated on-device (端侧) AI filing category; previously CAC filings covered cloud services only. 988 cloud services had been filed as of June 30.

# Why it matters

- A regulatory milestone for on-device AI in China: both a major foreign assistant (Apple Intelligence) and leading domestic assistants are now formally filed, signaling edge generative AI is entering the regulated mainstream.
- Directly relevant to device makers and anyone shipping AI features in the China market.
- Apple's partnership with Alibaba 千问 (rather than OpenAI) signals how global AI products enter China: "local model + local data + local compliance".
- The 2nd-gen Doubao AI phone (Byte × ZTE Nubia) is expected to launch at WAIC on July 17 now that its filing is complete.

# Evidence and caveats

- Confirmed via 财联社, 财经, 上海证券报, 第一财经, and CAC official announcement (2026-07-15). All 7 named services now confirmed from multiple independent Chinese media sources. Apple-千问 partnership confirmed by Alibaba chairman Joe Tsai's public statement and 财经 coverage. Apple Intelligence filing date: July 8, 2026 (per CAC).

# Citations

1. [财经 — 7款手机端侧AI完成备案，苹果、豆包AI手机上市提速](https://new.qq.com/rain/a/20260715A0AFAE00)
2. [上海证券报 — AI手机备案公示 行业发展将有何变化?](https://www.stcn.com/article/detail/4022019.html)
3. [第一财经 — Apple智能等7款手機AI服務完成備案](https://new.qq.com/rain/a/20260716A02GMD00)
