---
type: Reference
title: Google ships Nano Banana 2 Lite for fast AI images and Gemini Omni Flash for video via API
description: Google released Nano Banana 2 Lite ($0.034/image at 1K, ~4s, gemini-3.1-flash-lite-image API) and brought Gemini Omni Flash video generation ($0.10/second) out of I/O preview into the Gemini API and Google AI Studio; Google recommends chaining both via the Interactions API.
resource: https://ai.google.dev/gemini-api/docs/image-generation
tags: [ai-news, google, nano-banana, gemini, image-gen, video-gen, developer]
timestamp: 2026-07-15T11:45:00+08:00
published_at: 2026-07-14
published_at_raw: "Google launches Nano Banana 2 Lite for fast AI images and Gemini Omni Flash for video via API"
published_precision: date
retrieved_at: 2026-07-15T03:49:31Z
event_date: 2026-07-14
---

# What happened

Google released two generative-AI models on 2026-07-14:

- **Nano Banana 2 Lite** (`gemini-3.1-flash-lite-image`) — text-to-image in ~4 seconds at **$0.034 per 1K image**. Positioned for high-throughput developer pipelines and rapid ideation. It replaces the original Nano Banana (Gemini 2.5 Flash Image). The Nano Banana family now has three production models: Nano Banana 2 Lite ($0.034), Nano Banana 2 ($0.067), Nano Banana Pro ($0.134).
- **Gemini Omni Flash** — first shown at Google I/O, now generally available through the Gemini API and Google AI Studio. Combines Gemini multimodal reasoning with video generation and editing. Pricing **$0.10/second of video output** (matches Veo 3.1 Fast). Currently limited to 10-second clips; audio references and scene extension not yet supported in the API; character consistency across cuts is still limited.

Both models are also rolling out across Google's consumer surfaces: AI Mode in Search, the Gemini app, NotebookLM, Google Photos, Stitch, Google Flow, and Google Ads.

Google's recommended workflow chains the two: use Nano Banana 2 Lite to generate reference images, pass them to Gemini Omni Flash to animate into video. The Interactions API (now Google's default AI API surface) preserves session history and allows up to three consecutive edits. Three bundled demo apps ship in AI Studio to demonstrate the pattern: "Anywhere" (selfie at a landmark → animated result), "Space Lift" (room photo → interior-design video), "Omni Product Studio" (product image → e-commerce video).

Both outputs carry SynthID watermarks, verifiable through the Gemini app, Gemini in Chrome, or Google Search.

# Why it matters

The pricing puts sub-four-second, sub-penny-class image generation on a developer-friendly rail — meaningful for high-throughput generative use cases (catalog imagery, ad creative, A/B ideation) that previously couldn't justify the per-image cost. The Interactions API default signals Google is treating image+video chain workflows as the primary unit, not single-shot generation.

The video API at $0.10/second matches Veo 3.1 Fast, which keeps Google competitive with OpenAI's video positioning while opening it to general developer access for the first time. The 10-second clip ceiling is the obvious next bottleneck to watch.

# Evidence and caveats

Primary source: Google AI Studio + Gemini API documentation (`ai.google.dev`) and bundled demo apps, fetched via The Decoder's 2026-07-14 launch article which cites Google's API docs and pricing verbatim. Independent: The Decoder aggregates Google's positioning, the three-model pricing table, and the chain-workflow recommendation. Vendor-sourced but fact-rich and directly relevant. Treat Google's "reliable prompt following" claim as a vendor claim until independent benchmarks reproduce it. Quality score 9, promotional risk 1.

# Citations

1. [Google AI Studio — bundled apps (Anywhere)](https://aistudio.google.com/apps/bundled/anywhere)
2. [Gemini API — image generation documentation](https://ai.google.dev/gemini-api/docs/image-generation)
3. [Gemini API — pricing (Nano Banana 2 Lite)](https://ai.google.dev/gemini-api/docs/pricing#gemini-3.1-flash-lite-image)
4. [The Decoder — Google launches Nano Banana 2 Lite + Gemini Omni Flash](https://the-decoder.com/google-launches-nano-banana-2-lite-for-fast-ai-images-and-gemini-omni-flash-for-video-via-api/)
5. [DeepMind — SynthID verification](https://deepmind.google/blog/identifying-ai-generated-images-with-synthid/)