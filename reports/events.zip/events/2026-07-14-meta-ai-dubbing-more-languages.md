---
type: Reference
title: Meta expands AI dubbing of Reels to ten more languages across Instagram and Facebook
description: Per Adam Mosseri's Instagram post, Meta AI translation of Reels expanded to Japanese, Korean, French, German, and Italian on Instagram, and to Bahasa, Indonesian, Arabic, French, Vietnamese, and Thai on Facebook. Verge (Jay Peters) covered on 2026-07-14.
resource: https://www.theverge.com/news/761665/meta-ai-translation-facebook-instagram-reels
tags: [ai-news, meta, translation, instagram, facebook, reels]
timestamp: 2026-07-15T10:59:00+08:00
published_at: 2026-07-14
published_at_raw: "2026-07-14 (Verge); Instagram CEO post same day"
published_precision: date
retrieved_at: 2026-07-15T03:05:15Z
event_date: 2026-07-14
---

# What happened

Meta is bringing its AI translation tool to more Facebook and Instagram
users, automatically dubbing Reels into another language while matching the
speaker's mouth movements. Per Instagram head Adam Mosseri's Instagram post
on 2026-07-14, the supported language set expands to:

- **Instagram:** Japanese, Korean, French, German, Italian.
- **Facebook:** Bahasa, Indonesian, Arabic, French, Vietnamese, Thai.

The Verge (Jay Peters) corroborates Mosseri's announcement and notes that
the lip-syncing and pre-publish review controls already introduced for the
English↔Spanish rollout (announced at Meta Connect 2024) carry over.

# Why it matters

Translation-quality is one of the more visible AI applications on
short-form video. Adding ten languages across two of the largest social
platforms is a measurable expansion of a global content surface and is a
direct competitive response to YouTube's auto-dubbing and TikTok's
language-expansion moves. Lip-sync remains the technical differentiator
that Meta has been pushing since Connect 2024.

# Evidence and caveats

Primary: Adam Mosseri's Instagram post (linked from Verge). Vendor-sourced;
treat Meta's framing of "high-quality dubbing" as a company claim. Some of
the languages appear redundantly across Instagram and Facebook rolls —
worth noting that Meta is targeting two different audience pools via the
same model. Quality score 8, promotional risk 1 (vendor, but fact-rich and
directly relevant).

# Citations

1. [The Verge — Meta's AI can now dub your voice in more languages](https://www.theverge.com/news/761665/meta-ai-translation-facebook-instagram-reels)
2. [Adam Mosseri's Instagram announcement](https://www.instagram.com/p/DaxpKQfRaSV/)
3. [Meta for Creators — AI translations blog](https://creators.facebook.com/blog/meta-ai-translations)
