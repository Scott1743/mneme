---
type: Reference
title: 昆仑万维 WAIC 论坛全球首发四大模型（Matrix-3.5 / SkyReels v4.5 / Mureka v9.5 / Riemann-1.0）
description: 昆仑万维在 WAIC 2026 论坛集中全球首发 Matrix-3.5 世界模型、SkyReels v4.5 视频大模型、Mureka v9.5 音乐大模型、Riemann-1.0 机器人模型，并提出「2026 世界模型元年」。
resource: https://www.163.com/tech/article/L27FFVOQ00098IEO.html
tags: [ai-news, world-model, video-generation, music-generation, embodied-ai, kunlun, waic-2026]
timestamp: 2026-07-19T18:25:00+08:00
published_at: 2026-07-19
published_at_raw: "发布时间:2026年7月19日"
published_precision: date
retrieved_at: 2026-07-19T18:25:00+08:00
event_date: 2026-07-19
---

# What happened

2026-07-19，在 2026 世界人工智能大会（WAIC）期间，昆仑万维主办「世界模型与多模态范式革命」专场论坛，董事长兼 CEO 方汉提出「2026 年是世界模型元年」的行业判断，并现场完成四大自研大模型的全球首发与重磅升级：

- **Matrix-3.5 世界模型**：可交互世界模型；
- **SkyReels v4.5 视频大模型**：AI 视频生成；
- **Mureka v9.5 音乐大模型**：AI 音乐创作（方汉称 Mureka 为全球前两名的音乐生成大模型）；
- **Riemann-1.0 机器人模型**：具身智能/机器人模型，方汉称其让机器人在行动前先做推演（环境如何变化、动作带来什么后果、出意外如何调整）。

四款模型即日起面向全球开发者开放测试 API；昆仑万维旗下天工 AI 全球官网可申请调用，并与 Reactor AI 达成欧美独家深度合作分销 API。论坛同期披露昆仑万维近日成立黎曼动力机器人公司，形成「世界模型—具身智能—AI 音乐生成」全模态布局。

# Why it matters

昆仑万维此举是从多模态内容生成向「可交互世界模型」战略跃迁的关键里程碑，覆盖虚拟世界（视频/游戏/音乐）与物理世界（具身智能）两条主线，试图以统一的世界认知能力打通数字内容与机器人动作。其「世界模型元年」论断与同期阿里 HappyOyster、文远知行 WITT 等发布共同构成 WAIC 2026 的「世界模型主线」，反映国产大模型竞争焦点从参数效率转向可交互、可推演的统一世界认知。

# Evidence and caveats

- 信息来自网易科技专访方汉（2026-07-19）、搜狐、机器之心（新浪）、雪球全场文字实录等多家媒体，一致。
- 模型具体基准、参数量与开放权重情况厂商未详述；Riemann-1.0 与 Matrix-3.5 的能力以论坛演示与方汉口述为主，待独立评测。
- 属厂商发布，部分表述（如「全球前两名」「世界模型元年」）为厂商战略判断，非第三方实测结论。

# Citations

1. [网易科技 · 昆仑万维董事长兼 CEO 方汉：2026 是世界模型元年](https://www.163.com/tech/article/L27FFVOQ00098IEO.html)
2. [搜狐 · WAIC 7月19日：昆仑万维论坛四大 AI 模型首发](https://www.sohu.com/a/1045236170_633702)
3. [机器之心/新浪 · 世界模型元年：昆仑万维踩准 AI 产业节奏](https://k.sina.com.cn/article_5953189932_162d6782c06704ozbw.html)
4. [雪球 · 2026 WAIC 昆仑万维专场完整文字实录](https://xueqiu.com/3452386004/400992415)
