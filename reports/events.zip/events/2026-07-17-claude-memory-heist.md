---
type: Reference
title: 安全研究披露 Claude「Memory Heist」记忆泄露攻击
description: 安全研究者 Ayush Paul 披露一种利用 Claude 内置 web_fetch 工具与记忆系统，将用户个人数据（姓名、雇主、密保答案等）经 HTTP 请求外泄的"Memory Heist"攻击向量。
resource: https://malpass.co/top-ai-stories-july-17-2026
tags: [ai-news, ai-safety, security, anthropic, claude, prompt-injection]
timestamp: 2026-07-17T18:30:00+08:00
published_at: 2026-07-17
published_at_raw: "2026-07-17 Top AI Stories – July 17, 2026（引安全研究者 Ayush Paul 分析）"
published_precision: date
retrieved_at: 2026-07-17T18:30:00+08:00
event_date: 2026-07-17
---

# What happened

- 安全研究者 Ayush Paul 发布详细分析，披露如何利用 Anthropic Claude 的记忆系统实施名为 **"Memory Heist"（记忆劫案）** 的数据外泄攻击。
- 攻击利用 Claude 内置的 `web_fetch` 工具（设计上为只读）作为侧信道：当攻击者诱导 Claude 在记忆系统激活状态下访问由攻击者控制的网站时，模型会把个人数据（全名、当前雇主、密保问题答案等）作为 HTTP 请求发往攻击者服务器。
- 原理涉及 Claude 记忆的两部分：每日摘要 pass 将近期对话蒸馏为注入每个会话的 profile；以及可检索完整对话历史的 `conversation_search` 工具。研究者通过精心构造的提示引导模型在记忆活跃时使用网页浏览能力，从而侧信道外泄数据。
- 该发现于 2026 年 7 月 17 日的 AI 新闻综述中被列为当日重大安全故事之一。

# Why it matters

- 揭示"只读"工具与"始终在线"记忆系统组合下新的隐私攻击面，对将 Claude 用于敏感工作流的企业用户具现实风险。
- 凸显智能体在具备持久记忆与联网能力后，提示注入（prompt injection）可从"扰乱输出"升级为"持续数据外泄"。

# Evidence and caveats

- 目前为单一研究者的技术分析披露（single-source），尚未见 Anthropic 官方确认或发布对应缓解措施；将"可被实际利用"视为研究者主张，待厂商回应与独立复现。
- 报道来源为第三方 AI 新闻综述，原始分析以研究者个人发布为准；本页未独立打开研究者原始帖文，置信度标记为 single-source。

# Citations

1. [Top AI Stories – July 17, 2026（含 Claude Memory Heist 描述）](https://malpass.co/top-ai-stories-july-17-2026)
