---
type: Reference
title: 中科曙光 8000「登峰」全国产十万卡 AI 超集群亮相 WAIC
description: 中科曙光全国产十万卡 AI 超集群曙光8000（登峰）于 WAIC 2026 全球首秀并入选"镇馆之宝"，采用超智融合路线，FP64–INT8 全精度，全链路自研。
resource: https://new.qq.com/rain/a/20260721A08MLQ00?refer=cp_1009
tags: [ai-news, infrastructure, supercluster, sugon, waic, compute]
timestamp: 2026-07-21T18:25:00+08:00
published_at: 2026-07-21
published_at_raw: "2026年7月21日（收官综述）；WAIC 现场首秀 2026-07-17"
published_precision: date
retrieved_at: 2026-07-21T18:25:00+08:00
event_date: 2026-07-17
---

# What happened

中科曙光旗下全国产十万卡 AI 超集群 **"曙光8000（登峰）"** 在 WAIC 2026 首次面向全球公开亮相，并入选大会"十大镇馆之宝"。

系统采用**超智融合**技术路线，将科学计算与智能计算原生融合，支持 FP64 至 INT8 全精度计算，覆盖科学计算、大模型训练与推理、工业仿真等多类场景。核心系统能力：
- 全球首创高密度机柜结构，单个计算单元算力密度较其他超节点提升 **20 倍**；
- 自研 scaleFabric 类 IB 原生 RDMA 高速互连，实现十万卡规模超高速稳定互连；
- 自研分布式存储与低 PUE 浸没液冷，攻克十万卡集群稳定运行痛点；
- 贯通芯片、计算、存储、网络、散热、应用、服务全链路自主研发。

已依托国家超算互联网接入全国一体化算力网，完成 300 余项重点应用优化，覆盖大模型、机器人、创新药、新材料等 20 余个领域。

# Why it matters

标志我国超大规模算力基建实现关键跨越：从"建得成"走向"用得好、服务广、可复制"，也反映算力竞争计量单位从单芯片性能变为超节点与万卡集群、从参数变为落地成本。曙光8000 是"全国产十万卡"里程碑，与华为 Atlas 950 SuperPoD、阿里平头哥真武 M890/磐久 AL128 超节点共同构成 WAIC 2026 的国产算力矩阵。

# Evidence and caveats

信源为央广网（2026-07-17 现场报道）与 WAIC 收官综述（2026-07-21）。算力密度/互连/精度等为**厂商口径**；与 2026-07-17 入库的华为 Atlas 950 SuperPoD（见 [2026-07-17 digest](/news/digests/2026-07-17.md)）为不同厂商超节点方案，未合并。

# Citations

1. [首次全球亮相的曙光8000和中国AI算力的跃迁（央广网）](https://www.toutiao.com/article/7663387393370407458)
2. [2026WAIC收官，看见物理AI的落地与未来（腾讯新闻）](https://new.qq.com/rain/a/20260721A08MLQ00?refer=cp_1009)
3. [WAIC 2026 十大镇馆之宝公布](http://www.hellotw.com/gate/big5/x.8w.lol/newsFpIkHkr8/)
