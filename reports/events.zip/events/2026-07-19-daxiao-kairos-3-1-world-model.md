---
type: Reference
title: 大晓机器人发布开悟世界模型 3.1（Kairos 3.1）具身世界模型
description: 大晓机器人在 WAIC 2026 发布开悟世界模型 3.1（Kairos 3.1），统一隐空间融合视觉/语言/力触，打通「理解-推演-执行-反思」自进化闭环，Jetson Thor 端侧 8B 推理延迟 125ms，同步开源 L5 级家居数据集。
resource: https://www.163.com/tech/article/L27HI47900098IEO.html
tags: [ai-news, world-model, embodied-ai, robotics, daxiao, waic-2026]
timestamp: 2026-07-20T18:25:00+08:00
published_at: 2026-07-19T18:01:30+08:00
published_at_raw: "2026-07-19 18:01:30"
published_precision: datetime
retrieved_at: 2026-07-20T18:25:00+08:00
event_date: 2026-07-19
---

# What happened

2026-07-19，在 WAIC 2026 期间，大晓机器人发布开悟世界模型 3.1（Kairos 3.1）及以人为中心的环境式数据采集方案 2.0。Kairos 3.1 采用混合 Transformer 架构，将视觉观测、语言指令、力触状态与策略轨迹压缩至统一隐空间，形成「理解—推演—执行—反思」的自进化智能闭环；其空间理解底座 ACE-BRAIN-0.5 在四项国际 3D 空间理解基准中拿下十二项 SOTA，HomeWorld 仿真覆盖 30 万套中国住宅平面图、5000 个全屋场景与 8700 个 3D 资产。在 NVIDIA Jetson Thor 平台 BF16 精度下，Kairos 3.1 8B 模型推理延迟仅 125 毫秒，依托自研 KairosRT 计算引擎实现端侧实时推理，并支持自主反思（执行失败时调整动作策略）。大晓同步推出即时零售「晓满」、酒店「晓新」、开放场景「晓途」三套方案，并宣布开源 L5 级家居复杂任务数据集 ACE-Data-0；同期国内首个具身物理智能统一评测基准平台「PHYSICAL IQ 物智」亮相。

# Why it matters

具身智能正从「理解/生成」走向「支撑真实行动」。Kairos 3.1 强调「降低机器人在真实世界的行动代价」而非画面逼真度，以统一隐空间与端侧 125ms 延迟把世界模型真正带入控制闭环，并借「信息密度定律」与 L5 数据集定义具身数据标准，为机器人规模化落地（即时零售、酒店、巡检）提供可验证的工程路径。

# Evidence and caveats

- SOTA/延迟为厂商口径，基准与实测条件待独立复现；「行动代价降低」等收益主张需长期运营指标验证。
- 属厂商发布。

# Citations

1. [网易智能 · 大晓发布世界模型及系列方案，陶大程：世界模型下半场要开始拼行动](https://www.163.com/tech/article/L27HI47900098IEO.html)
2. [新浪 · 大晓机器人发布三大核心成果，推动物理 AI 迈入规模化落地阶段](https://k.sina.com.cn/article_5953740931_162dee08306703ofpm.html)
