---
type: Reference
title: Anthropic 为 Claude Code 推送 v2.1.212/214，新增后台 fork、防 runaway 循环上限与终止会话工具
description: Anthropic 2026-07-18 为 Claude Code 推送 v2.1.212 与 v2.1.214，新增 /fork 后台会话、session 级 WebSearch/子 agent 上限（默认各 200）防失控循环、EndConversation 终止滥用/越狱会话等可靠性与安全控制。
resource: https://github.com/anthropics/claude-code/blob/main/CHANGELOG.md
tags: [ai-news, dev-tools, agent, anthropic, claude-code, safety]
timestamp: 2026-07-19T11:25:00+08:00
published_at: 2026-07-18
published_at_raw: "2026-07-18（Daily News）"
published_precision: date
retrieved_at: 2026-07-19T11:25:00+08:00
event_date: 2026-07-18
---

# What happened

- Anthropic 于 2026-07-18 为 Claude Code 连续推送 v2.1.212 与 v2.1.214。
- v2.1.212：将 `/fork` 改为把当前对话复制到一个新的后台会话，原 in-session 子 agent 变为 `/subtask`；新增 session 级上限——WebSearch 调用与子 agent 派生各默认上限 200，以遏制 runaway loop（失控循环）；新增 `claude auto-mode reset` 命令、运行超过 2 分钟的 MCP 工具调用自动转入后台，以及 `/resume` 会话选择器。
- v2.1.214：新增 EndConversation 工具，使 Claude 可主动结束存在严重滥用或越狱尝试的会话；为长时工具调用增加进度心跳（progress heartbeat）；对携带 daemon-redirect 标志的 docker 命令增加权限提示。
- 同日 Anthropic 还发布 Deputy CISO 的 agentic AI 风险框架（四问评估 + 七项控制，如身份来自既有 IdP、connector 白名单、逐动作审批、沙箱执行、针对提示注入的出站白名单、OpenTelemetry 上报 SIEM、全局 kill switch），以及 Cursor 对 Claude Fable 5 的 CursorBench 内部基准高分（72.9%）等案例研究。

# Why it matters

- 编码智能体的可靠性与安全防护在增强：防 runaway 循环上限直接应对 agent「自激循环烧 token/跑飞」的工程痛点，EndConversation 则为应对滥用与越狱提供了可控退出机制，反映 agent 产品从「能跑」走向「可控、可审计」。
- 与 Deputy CISO 的风险框架一并出现，说明头部实验室正把 agentic AI 的安全运营（identity、blast radius、observability、kill switch）作为企业落地的前置条件。

# Evidence and caveats

- 版本号、功能变更来自 Anthropic Claude Code CHANGELOG（GitHub）与 Anthropic 官方博客案例；经 my2cents.ai 2026-07-18 每日聚合转述与核对。属厂商侧发布，但 CHANGELOG 为可复核一手来源。
- 具体默认上限数值与行为可能随后续补丁调整，以 CHANGELOG 当前条目为准。

# Citations

1. [Claude Code CHANGELOG（Anthropic, GitHub）](https://github.com/anthropics/claude-code/blob/main/CHANGELOG.md)
2. [Anthropic AI Updates: July 18, 2026（my2cents.ai 聚合，含一手来源链接）](https://www.my2cents.ai/news/2026-07-18-anthropic)
3. [A CISO's guide to agentic AI（Anthropic 博客）](https://claude.com/blog/ciso-guide-to-agentic-ai)
