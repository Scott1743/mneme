---
type: Reference
title: 金山办公 WAIC 展示灵犀专业版与 WPS365 企业大脑（WPS Comate）
description: 金山办公在 WAIC 2026 展示面向个人的灵犀专业版（可交付可编辑 Office 成果）与面向组织的 WPS365 企业大脑 WPS Comate，行业首个将「企业大脑」交付落地。
resource: https://cj.sina.com.cn/article/norm_detail?url=https%3A%2F%2Ffinance.sina.com.cn%2Fjjxw%2F2026-07-19%2Fdoc-iniihuvm7972907.shtml
tags: [ai-news, office-ai, agent-productivity, kingsoft-wps, waic-2026]
timestamp: 2026-07-19T18:25:00+08:00
published_at: 2026-07-19T07:51:00+08:00
published_at_raw: "2026年07月19日07:51"
published_precision: datetime
retrieved_at: 2026-07-19T18:25:00+08:00
event_date: 2026-07-19
---

# What happened

作为 WAIC 2026「AI 办公效率合作伙伴」，金山办公现场展示两款 AI 办公智能体，分别对应个人与组织：

- **灵犀专业版（面向个人）**：定位「专业个人办公助理」，以项目为单位管理上下文、沉淀写作风格与数据偏好；能调用文档、处理数据、编写代码，直接产出**可继续编辑的 PPT、保留公式的表格、支持审阅的文档**——交付的是「拿来即用」的原生 Office 文件，而非参考建议。
- **WPS365 升级为一站式 AI 办公平台，落地「企业大脑」WPS Comate（面向组织）**：构建统一的企业级 AI 入口，将个人能力转化为组织能力；提供「技能」（员工创建分享）、「专家」（整合历史知识与系统接口）、「应用」（安全内部发布）三大模块，并提出「三通（知识/数据/能力）两管（成本/安全）一平（统平台）」体系。

背景：7 月 11 日金山办公 WPS AI 表格 Agent 再次登顶 SpreadsheetBench（Verified400 专家精标榜单 98.25%）；6 月其表格 Agent 以 73.46% 登顶 Full912 全量榜单并首次超越人类专家基线。

# Why it matters

反映 AI 办公从「会聊天的助手」转向「直接交付可用成果」的范式转变（本届 WAIC 主线之一）。金山办公将竞争焦点从「谁的模型更聪明」转向「把模型能力融入业务流程、沉淀为组织能力」，并以「企业大脑」形态把个人经验在全员范围流通复用，代表国内办公软件 AI 化的落地路径。

# Evidence and caveats

- 来源为扬子晚报/紫牛新闻经新浪财经转载（2026-07-19 07:51），及 21 世纪经济报道 WAIC 观察，信息一致。
- 能力描述以厂商演示与高管表述为主；SpreadsheetBench 登顶为可核验公开基准成绩。

# Citations

1. [新浪财经/扬子晚报 · WPS Comate 亮相 WAIC，行业首个企业大脑交付落地](https://cj.sina.com.cn/article/norm_detail?url=https%3A%2F%2Ffinance.sina.com.cn%2Fjjxw%2F2026-07-19%2Fdoc-iniihuvm7972907.shtml)
2. [21 世纪经济报道 · WAIC 观察：AI 开始交付了](https://m.21jingji.com/article/20260719/herald/92740b862f16360efe202f6a52e377de.html)
