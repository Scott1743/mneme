---
type: Reference
title: 平头哥开源 AI 软件栈 T-Head SAIL，国产超节点 WAIC 集中亮相
description: 平头哥 2026-07-18 在 WAIC 开源自研 AI 软件栈 T-Head SAIL（真武芯片底层软件），覆盖 OS/SDK/接口层并兼容 260+ 训练与推理框架；同期阿里云、华为、沐曦、中兴等国产超节点产品集中亮相。
resource: https://www.163.com/dy/article/L24P7A6Q0519DDQ2.html
tags: [ai-news, ai-infrastructure, open-source, domestic-chip, compute]
timestamp: 2026-07-18T18:25:00+08:00
published_at: 2026-07-18T16:17:41+08:00
published_at_raw: "2026-07-18 16:17:41 来源：第一财经资讯上海"
published_precision: datetime
retrieved_at: 2026-07-18T18:25:00+08:00
event_date: 2026-07-18
---

# What happened

- 2026-07-18 在 2026 世界人工智能大会（WAIC）上，平头哥半导体副总裁高慧表示，AI 时代的真正爆发来自「更开放、更协调、更高效的全栈策略算力体系」，并宣布开源自研 AI 软件栈 T-Head SAIL（SAIL）。
- T-Head SAIL 是真武（Zhenwu）AI 芯片的底层软件，架构覆盖 OS 层、SDK 层与接口层的完整链路，可最大程度释放真武芯片算力，全面兼容主流 AI 生态，适配 260 多个主流训练与推理框架。
- 国产超节点产品在本届 WAIC 集中亮相：平头哥展出真武 M890 磐久 AL128 超节点（单柜集成 128 颗芯片，自研 ALink 互连架构实现 Pb/s 级带宽与百纳秒级延迟）；阿里云灵骏真武 M890 超节点实例发布（阿里云首次通过公共云对外提供超节点形态算力）；华为展出 Atlas 950 SuperPoD（现场 1024 张昇腾 950DT，集群可扩展至 50 万卡）；沐曦发布曦景 S600 超节点；中兴通讯发布中兴 OEX 超节点新品。

# Why it matters

- 国产算力竞争正从「单颗芯片峰值」转向「系统级全栈效率」：智能体超长上下文多轮推理、多智能体高频协同等场景带来芯片空转等待、算力利用率下降、交互切换能耗激增等新问题，底层软件栈与超节点工程成为核心壁垒。
- 平头哥开源 AI 软件栈，意在以开放工具链与算子生态拉动国产芯片软硬协同；国盛证券近期研报称「国产超节点迎来量产元年」，系统级方案正成为国产算力「下半场」的竞争焦点。

# Evidence and caveats

- SAIL 架构、框架兼容数与超节点参数来自平头哥 / 华为 / 阿里云等官方信息经第一财经刊发的报道；属厂商侧发布（vendor-sourced），具体算力释放与互连带宽以后续基准核验。
- 「Pb/s 级带宽、百纳秒级延迟」「扩展至 50 万卡」等为厂商现场表述，真实集群表现需以交付与第三方测试为准。

# Citations

1. [从秀单卡到建体系，WAIC 见证国产算力系统性进化（第一财经经网易）](https://www.163.com/dy/article/L24P7A6Q0519DDQ2.html)
2. [腾讯动态：腾讯 ADP 4.0 海外版正式上线等（腾讯新闻汇总）](https://new.qq.com/rain/a/20260718A07KUX00?refer=cp_1009)
