---
type: Reference
title: "Tencent releases Hy-Embodied VLM and RxBrain, open-source embodied intelligence foundation models"
description: "Tencent Robotics X × Futian Lab × Hunyuan released two embodied intelligence foundation models: Hy-Embodied-VLM-1.0 (A3B, 1/10 compute of A32B flagship, comparable performance on 37 tasks) and Hy-Embodied-RxBrain-1.0 (6.2B, unified reasoning + visual imagination), both open-sourced on GitHub."
resource: https://github.com/Tencent-Hunyuan/Hy-Embodied-RxBrain-1.0
tags: [ai-news, model-release, open-source, embodied-ai, robotics, tencent]
timestamp: 2026-07-16T11:25:00+08:00
published_at: 2026-07-15T18:40:00+08:00
published_at_raw: "2026-07-15 18:40 · 机器之心Pro"
published_precision: datetime
retrieved_at: 2026-07-16T11:25:00+08:00
event_date: 2026-07-15
---

# What happened

- On July 15, 2026, Tencent Robotics X Lab, Futian Lab, and the Hunyuan (混元) team released two embodied intelligence foundation models:
  - **Hy-Embodied-VLM-1.0**: A second-generation embodied VLM built on the latest Hunyuan A3B base, with mid-training on large-scale embodied data. Achieves comparable performance to the previous A32B flagship model at **1/10 the compute** on 37 evaluation tasks. Scores: physical state understanding 68.6, action-change reasoning 64.1, temporal adaptive reasoning 57.4 (avg 65.6). Significantly outperforms same-size Qwen3.6-A3B, Cosmos 3-A8B, and Embodied-R1.
  - **Hy-Embodied-RxBrain-1.0**: A ~6.2B unified embodied cognition model that jointly performs **language reasoning + visual imagination** within a single autoregressive sequence. Trained on 50,000+ hours of high-quality embodied data. Capabilities: embodied understanding & reasoning (VQA, chain-of-thought), world state prediction (imagining near-future frames), joint subgoal planning (decomposing tasks into steps with both next-action language and goal images). Uses interleaved generation where a learned token decides when to "imagine" a frame.
- Both models are **open-sourced** on GitHub (Tencent-Hunyuan organization) with inference code, model weights, and technical reports.

# Why it matters

- RxBrain's unified reasoning+imagination design is architecturally novel: instead of separate language model + video generator, text reasoning and visual goal generation happen in one continuous cognitive sequence — providing denser, clearer multimodal conditions for downstream action models.
- VLM's 10x compute reduction at comparable performance pushes embodied AI toward practical edge deployment, critical for real-world robotics applications.
- Open-sourcing both models lowers the entry barrier for embodied AI research, addressing the "model generic, landing difficult" gap in the robotics field.

# Evidence and caveats

- Primary source: GitHub repo (Tencent-Hunyuan/Hy-Embodied-RxBrain-1.0) with inference code and model weights. Independent coverage from 机器之心, Chinaz, 网经社. Benchmark scores are vendor-reported; no independent reproduction yet.

# Citations

1. [GitHub — Tencent-Hunyuan/Hy-Embodied-RxBrain-1.0](https://github.com/Tencent-Hunyuan/Hy-Embodied-RxBrain-1.0)
2. [机器之心 — 腾讯发布具身智能基座模型](https://new.qq.com/rain/a/20260715A0A3UL00)
3. [Chinaz — 腾讯发布两大具身智能基座模型](https://www.100ec.cn/detail--6661412.html)
