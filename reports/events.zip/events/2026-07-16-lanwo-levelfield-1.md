---
type: Reference
title: 蓝沃 AI 开源「沃土」工业大模型 LevelField-1（非标机加工工艺）
description: 蓝沃（上海）智能数字科技开源发布 LevelField-1，行业首个聚焦非标机加工工艺的大模型，基于通义千问基座、90 亿参数、Apache 2.0，可读取 2D 图纸自动推导加工步骤与工艺路线。
resource: https://www.163.com/dy/article/L1V9E35C05509EKV.html
tags: [ai-news, open-source, industry, vertical-model, qwen, manufacturing]
timestamp: 2026-07-16T18:25:00+08:00
published_at: 2026-07-16T13:05:34+08:00
published_at_raw: "2026-07-16 13:05:34"
published_precision: datetime
retrieved_at: 2026-07-16T18:25:00+08:00
event_date: 2026-07-16
---

# What happened

蓝沃（上海）智能数字科技有限公司（蓝沃 AI）在世界人工智能大会前夕开源发布「沃土」工业大模型 LevelField-1。据全球 TMT 报道，这是行业首个聚焦非标机加工工艺的大模型：能读懂一张 2D 图纸中的工件结构、公差、粗糙度等加工要求，自动推导加工步骤并给出工艺路线与优化建议。模型基于通义千问开源基座，90 亿参数，使用上海精智 16 家工厂图纸库中的 10 万张工艺图纸及配套工艺信息完成微调与强化学习；由蓝沃技术团队与 36 位从业 20 年以上的工艺工程师共同构建数据与校验。本次开源为合并后完整权重（safetensors，约 20G）及全套运行文件，采用 Apache 2.0 协议，免费商用，支持车削、铣削、钻削、磨削、铸造、锻造、热处理、焊接等 18 类机加工工艺。

# Why it matters

垂直行业大模型从「通用对话」走向「能办事」：LevelField-1 把资深工艺工程师的经验沉淀为可复用模型，内部评测与工艺工程师思路契合度 95% 以上，内测客户工艺路线起草耗时减少约 60%。它体现了国产开源基座（通义千问）在制造业细分场景的落地路径——以高质量行业数据 + 专家校验构筑专业壁垒。

# Evidence and caveats

- 来源为厂商新闻稿（全球 TMT / 网易），披露了具体基座、参数、许可与评测数据；目前未见独立第三方复现。
- 「契合度 95%」「耗时减 60%」为厂商内部/内测口径，属 vendor claim。
- 权重与代码是否已在 Hugging Face / ModelScope 实际可下载，以官方仓库为准（报道称已开源）。

# Citations

1. [全球 TMT·蓝沃 AI 开源 LevelField-1（2026-07-16 13:05）](https://www.163.com/dy/article/L1V9E35C05509EKV.html)
