---
type: Reference
title: Google 开源 Agents CLI：面向编程智能体的全生命周期工程工具包
description: Google 开源 Agents CLI（github.com/google/agents-cli，约 5.1k stars），以 CLI + 7 项 Skills 为 Claude Code、Codex 等编程智能体提供从开发、评测、部署到可观测性的工程化链路。
resource: https://github.com/google/agents-cli/
tags: [ai-news, open-source, dev-tools, agents, google]
timestamp: 2026-07-17T11:25:00+08:00
published_at: 2026-07-16T15:20:00+08:00
published_at_raw: "2026-07-16 15:20 发布于北京 科技领域创作者（智猩猩整理）"
published_precision: datetime
retrieved_at: 2026-07-17T11:25:00+08:00
event_date: 2026-07-16
---

# What happened

- Google 开源项目 Agents CLI（仓库 github.com/google/agents-cli，GitHub 约 5.1k stars），不是新的编程智能体，而是给 Claude Code、Codex 等编程智能体"装上"的 CLI + Skills 工具包。
- 内置 7 项 Skills：workflow（生命周期/模型选择/代码保护）、ADK 代码、脚手架、评测（LLM-as-a-Judge）、部署（Agent Runtime/Cloud Run/GKE）、企业发布、可观测性（Cloud Trace/BigQuery Agent Analytics/第三方）。
- 覆盖从本地脚手架、依赖管理、本地调试、质量检查、评测、基础设施配置、云端部署到生产发布与追踪的完整生命周期；让编程智能体沿标准化路径完成 Agent 开发到上线。
- 仍处于 Preview 阶段；环境要求 Node.js、Python 3.11+、uv。

# Why it matters

- 把"怎么做 Agent"推向"怎么长期经营 Agent"，将开发/评测/部署/运维经验沉淀为机器可重复执行的工程系统。
- 降低编程智能体接入生产系统的工程摩擦，反映 Agent 工程化趋势。

# Evidence and caveats

- 一手来源为 GitHub 仓库与官方架构说明；中文报道来自智猩猩整理，细节可信但属二手。
- 项目处 Preview 阶段，对企业复杂项目与长期生产环境的适应性仍待验证。

# Citations

1. [GitHub: google/agents-cli](https://github.com/google/agents-cli/)
2. [智猩猩/腾讯新闻：5.1k Stars！谷歌开源 Agent 工程神器](https://new.qq.com/rain/a/20260716A07DAI00)
