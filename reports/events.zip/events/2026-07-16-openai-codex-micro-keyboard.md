---
type: Reference
title: OpenAI 联合 Work Louder 推出首款硬件 Codex Micro 可编程键盘（$230）
description: OpenAI 与加拿大外设厂商 Work Louder 联名推出 Codex Micro（$230），面向 Codex 编程智能体的专用控制终端，以 RGB 状态灯回传多 agent 运行状态，7 月下旬发货。
resource: https://openai.com/zh-Hans-CN/supply/co-lab/work-louder/
tags: [ai-news, product, openai, codex, hardware, agents]
timestamp: 2026-07-16T18:25:00+08:00
published_at: 2026-07-16T00:00:00+08:00
published_at_raw: "2026-07-16"
published_precision: date
retrieved_at: 2026-07-16T18:25:00+08:00
event_date: 2026-07-16
---

# What happened

OpenAI 与加拿大键盘厂商 Work Louder 联名推出 Codex Micro（型号 kbd-1.0-codex-micro），售价 230 美元，定位为面向 AI 编程智能体 Codex 的「智能体工作指挥中心」，已开启预购、预计 7 月 24 日发货。据 PChome / QQ 科技及 frontiernews.ai 报道，设备基于 Work Louder Creator Micro 2 平台，CNC 铝合金机身，含 13 枚低剖面机械按键、1 个旋转编码器、1 个二维摇杆与电容触控；6 枚「Agent 键」通过 RGB 灯效实时回传 Codex 智能体状态（思考中/运行中/等待中/完成/错误），摇杆触发 PR Review、调试、重构等流程，旋钮实时调节 Codex 推理强度，并支持 push-to-talk 语音输入。设备本身不做 AI 计算，仅通过 USB-C / BLE 与 Codex 联动（Agent 键状态回传需 ChatGPT 桌面端运行）。

# Why it matters

这是 OpenAI 首款面向市场销售的品牌硬件外设，信号意义大于硬件本身：它把「AI 干活、人来拍板」的多 agent 并行工作流固化为一台实体控制台，反映 AI 工具生态从纯软件走向「软硬协同」的交互终端。其架构依赖 7/9 起并入 ChatGPT 桌面的 Codex，也折射出 OpenAI 围绕 agent 工作流打造专属交互设备的产品判断。

# Evidence and caveats

- 多源报道一致（PChome via QQ、frontiernews.ai），并对应 OpenAI 官方 supply 页面；属 vendor 产品发布，事实丰富。
- 核心 Agent 键功能依赖 ChatGPT 桌面端作为客户端桥接；CLI / VS Code / 浏览器用户该功能不可用。
- 硬件本体为 Work Louder 现成产品定制联名，溢价包含品牌因素；实用性取决于多 agent 并行工作流是否普及。

# Citations

1. [OpenAI 官方 supply 页面（Work Louder 联名）](https://openai.com/zh-Hans-CN/supply/co-lab/work-louder/)
2. [PChome 报道 via QQ 科技（2026-07-16）](https://new.qq.com/rain/a/20260716A078OY00?refer=cp_1009)
3. [frontiernews.ai：OpenAI's $230 Codex Micro Hardware Launches Today](https://www.frontiernews.ai/news/article/openais-230-codex-micro-hardware-launches-today-wh-a45861f8)
