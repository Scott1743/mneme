---
name: mneme
version: 3.3.0
description: "维护并搜索一座本地、agent 增量维护的 OKF v0.1 Markdown wiki，含可选的每天 23:00 agent 健康任务（仅报告或受限自动修复模式）。当用户想要 dream（捕获或整理知识）、search（召回并综合它）、初始化 wiki，或排程 wiki 健康维护时使用。触发词：'mneme'、'my wiki'、'remember this'、'dream about X'、'search my wiki'、'nightly wiki health'、'查 wiki'、'搜索知识库'、'梦'、'记住这个'。v3.3 默认 SQLite FTS5，并持久化显式启用的 L2 语义模式。"
allowed-tools:
  - Read
  - Write
  - Edit
  - Bash
  - Glob
  - Grep
  - AskUserQuestion
---

# mneme — 轻量化 LLM wiki

使用原生工具加本 skill 自带的确定性 CLI。绝不调用独立的 agent SDK 或工具框架：原生工具就是 agent 运行时，而 OKF Markdown bundle 是唯一真相源。

```bash
python3 ~/.claude/skills/mneme/scripts/mneme.py <子命令> [参数]
```

用户表面只有两个意图：`dream` 在预览与批准后写入；`search` 读取并回答。`init`、`lint`、`reindex`、`dream`、`search`、`convert` 是这些工作流调用的内部 CLI 操作。

## 每个任务只解析一次 bundle

按以下顺序使用第一个可用的位置：

1. 用户显式提供的 bundle 路径。
2. `$MNEME_BUNDLE`。
3. `$HOME/.config/mneme/config.toml` 中的 `bundle_path` 键。
4. 从当前工作目录向上查找带 `okf_version` frontmatter 的根 `index.md`。
5. 当 `./wiki` 存在时使用它。
6. 否则询问路径或提供内部 `init` 命令。

在当前任务内复用已解析的路径。仅当用户选择了另一个 bundle，或相关环境/配置发生变化时才重新解析。不要依赖持久的 agent 记忆来选择 bundle。

## OKF v0.1 写入契约

1. 每个非保留的 `.md` 文件必须含可解析的 YAML frontmatter。
2. 每个 frontmatter 必须含非空的 `type` 字段。
3. 保留文件 `index.md` 和 `log.md` 必须遵循各自的 OKF 结构。
4. 每个 Mneme 写作的概念页至少含一个 `tags` 值。
5. 使用绝对 bundle-relative 链接，如 `/concepts/example.md`。

消费者容忍未知的 `type` 值、额外的 frontmatter 键、缺失的可选字段、断链以及缺失的 index。在有用时报告它们；但绝不因此拒绝 bundle 的其余部分。

## 场景：dream [来源或整理请求]

`dream` 是写侧的 host-agent 工作流。`mneme dream` CLI 仅仅是只读审计步骤，没有 apply 模式。

批准之前：

1. 解析 bundle。若不存在，预览拟议位置，并仅在用户同意创建后才使用 `init`。
2. 读取提供的来源，不复制或修改 bundle。当本地 PDF、DOCX 或 PPTX 无法读取时，用 `mneme convert` 提供一次预览式转换，输出到一个显式的临时路径；它只会调用用户已安装的兼容转换器。
3. 运行 `python3 ~/.claude/skills/mneme/scripts/mneme.py dream --bundle <bundle> --json`
   以审计当前 bundle 而不写入。
4. 阅读相关的现有页面并准备一份具体的变更预览：原始来源的去向、要新增或编辑的页面、frontmatter/tags、链接，以及计划中的 `index.md` 与 `log.md` 更新。
5. 展示审计与拟议变更集。在每次 bundle 写入之前，包括把原始来源复制进 `sources/`，都要求显式的用户批准。这条逐次批准规则约束交互式 dream；唯一例外是下方用户自选的夜巡受限持续授权。

仅在获得批准之后、写入之前，加载 `references/workflow-dream.md`。在以下情况下它是必读的：首次 dream、拟议页面超过五个、要编辑现有概念页、出现冲突、合并或归档提案。只应用已批准的范围。若范围必须实质性地扩展，先预览并再次询问。

绝不自动暂存、提交、推送、合并、归档或删除知识。绝不由文本或向量分数做出这些决定。

### 提供夜巡健康任务

当用户直接请求排程式 wiki 维护时，立即按本节执行。否则，在对某个 bundle 完成 `init` 或首次成功的交互式 `dream` 之后，若宿主具备 recurring-task 能力，则检查该 bundle 是否已有夜巡 Mneme 任务。若不存在，提供一次创建每天 23:00 本地时间任务的选项，并请用户在两种模式间选择其一：

- **只报告**：被调度的 agent 审计、lint、阅读相关页面并报告发现，不改动 bundle。
- **受限自动修复**：被调度的 agent 只可应用 `references/workflow-nightly-dream.md` 中有限且非破坏性的健康修复，随后校验并报告精确 diff。用户的显式模式选择仅构成对该狭窄修复范围的持续授权。

在用户显式选择模式之前，不要创建或修改 recurring task。尊重此前的拒绝，不反复提示。在组合任一调度任务之前加载 `references/workflow-nightly-dream.md`。使用 host-agent 的 recurring task，而不是 `mneme dream --schedule`：那个 CLI 标志是无 agent、仅报告的调度器代码片段兜底，无法执行修复。

## 场景：search <问题>

`search` 是读侧的 host-agent 工作流。CLI 只返回导航候选；答案由 agent 产出。

1. 先读根 `index.md`，再通过标题、tags、链接和本地文本匹配渐进展开。
2. 当需要排序后的候选时，运行：
   `python3 ~/.claude/skills/mneme/scripts/mneme.py search "<question>" --json -k 10`。
3. 当用户显式请求语义召回时，加载 `references/index-design.md`。在用户安装可选依赖后，运行一次 `reindex --l2` 构建并激活 L2。之后的普通 `search` 命令会使用持久化的 L2 模式；绝不要为每次 search 添加 `--l2`、安装依赖、下载模型或替用户切换模式。L2 失败时绝不静默回退到 FTS5。
4. 始终完整阅读每个相关的 Markdown 页面。片段、chunk、距离值以及派生的 SQLite 索引从不具有权威性。
5. 综合答案时使用行内 bundle-relative 引用，如 `[示例](/concepts/example.md)`。
6. 如实陈述覆盖缺口。若某个可复用的答案应当被保留，提议一次单独的 `dream`；`search` 本身从不写入。

仅在多页综合、存在多个似是而非的候选、需要引用的答案、语义召回，或对召回与权威性存疑时，加载 `references/workflow-search.md`。简单的已知路径或精确标题查找不需要加载它。

## 内部维护命令

- `init <path>` 脚手架生成一个 OKF bundle 并记录其位置。
- `lint [--bundle <path>]` 校验与诊断，不改动页面。
- `reindex [--bundle <path>] [--l2 | --fts5]` 原子地重建当前生效的可删除索引。`--l2` 显式构建并持久化语义模式；`--fts5` 显式切回。裸 `reindex` 使用已持久化的模式。
- `dream [--bundle <path>] --json` 只读审计，不写入。其可选的调度标志仅打印无 agent、仅报告的调度器代码片段，绝不安装它们；默认兜底时间为本地 23:00。
- `search <query> [--bundle <path>] --json` 从已持久化的模式返回候选。
- `convert <source> --output <path>` 用一个已安装的兼容转换器产出派生的可读文本；它绝不安装软件，且除非用户显式请求 `--force`，否则拒绝覆盖。

仅在显式进行 wiki 健康检查，或 dream 后校验失败时，加载 `references/workflow-lint.md`。仅在索引模式选择或排障时，加载 `references/index-design.md`。在结构性变更或 bundle 增长时，加载 `references/wiki-structure.md`。仅在页面类型未知或存在争议时，加载 `references/type-vocab.md`。

## References

- `references/workflow-dream.md` —— 批准后的写侧流程；仅在批准之后、写入之前加载。
- `references/workflow-nightly-dream.md` —— 每天 23:00 的 recurring agent 任务模式、持续授权边界、受限修复与报告格式。
- `references/workflow-search.md` —— 全页综合与引用流程；仅在前述 search 条件下加载。
- `references/workflow-lint.md` —— 只读健康审查与诊断。
- `references/type-vocab.md` —— 可选的、非集中注册的类型指引。
- `references/wiki-structure.md` —— 增长中的 bundle 的组织方式。
- `references/index-design.md` —— 默认 FTS5 与显式 opt-in 的 L2 细节。

OKF 规范：<https://github.com/GoogleCloudPlatform/knowledge-catalog/blob/main/okf/SPEC.md>。
